package net.jaams.jaamsshinerite.tooltips;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.Screen;

import net.jaams.jaamsshinerite.init.JaamsShineriteModItems;

import javax.annotation.Nullable;

import java.util.List;

public class ShineriteStarTooltips {
	@OnlyIn(Dist.CLIENT)
	@SubscribeEvent
	public static void onItemTooltip(ItemTooltipEvent event) {
		execute(event, event.getItemStack(), event.getToolTip());
	}

	public static void execute(ItemStack itemstack, List<Component> tooltip) {
		execute(null, itemstack, tooltip);
	}

	private static void execute(@Nullable Event event, ItemStack itemstack, List<Component> tooltip) {
		if (tooltip == null)
			return;
		if (itemstack.getItem() == JaamsShineriteModItems.SHINERITE_STAR.get()) {
			tooltip.add(1, Component.literal((Component.translatable("translation.tooltip.dyeable").getString())));
			if (Screen.hasShiftDown()) {
				tooltip.add(2, Component.literal((Component.translatable("translation.tooltip.dyeable.desc").getString())));
			}
			if (Screen.hasShiftDown()) {
				tooltip.add(3, Component.literal((Component.translatable("translation.tooltip.throwable").getString())));
			} else {
				tooltip.add(2, Component.literal((Component.translatable("translation.tooltip.throwable").getString())));
			}
			if (Screen.hasShiftDown()) {
				tooltip.add(4, Component.literal((Component.translatable("translation.tooltip.throwable.desc").getString())));
			}
			if (Screen.hasShiftDown()) {
				tooltip.add(5, Component.literal((Component.translatable("translation.tooltip.glowstrike").getString())));
			} else {
				tooltip.add(3, Component.literal((Component.translatable("translation.tooltip.glowstrike").getString())));
			}
			if (Screen.hasShiftDown()) {
				tooltip.add(6, Component.literal((Component.translatable("translation.tooltip.glowstrike.desc").getString())));
			}
			if (!Screen.hasShiftDown()) {
				tooltip.add(Component.literal(""));
			}
			if (!Screen.hasShiftDown()) {
				tooltip.add(Component.literal((Component.translatable("translation.tooltip.details").getString())));
			}
		}
	}
}
