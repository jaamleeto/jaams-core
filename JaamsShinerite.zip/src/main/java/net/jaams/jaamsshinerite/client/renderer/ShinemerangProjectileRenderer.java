package net.jaams.jaamsshinerite.client.renderer;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.util.Mth;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.Minecraft;

import net.jaams.jaamsshinerite.entity.ShinemerangProjectileEntity;
import net.jaams.jaamsshinerite.configuration.JaamsShineriteClientConfiguration;

import com.mojang.math.Axis;
import com.mojang.blaze3d.vertex.PoseStack;

@OnlyIn(Dist.CLIENT)
public class ShinemerangProjectileRenderer extends EntityRenderer<ShinemerangProjectileEntity> {
	public ShinemerangProjectileRenderer(EntityRendererProvider.Context context) {
		super(context);
	}

	@Override
	public void render(ShinemerangProjectileEntity entity, float entityYaw, float partialTicks, PoseStack matrixStack, MultiBufferSource buffer, int packedLight) {
		matrixStack.pushPose();
		final float SCALE_FACTOR = JaamsShineriteClientConfiguration.SHINEMERANGSIZE.get().floatValue();
		matrixStack.scale(SCALE_FACTOR, SCALE_FACTOR, SCALE_FACTOR);
		float spinRotation = (entity.getAirTicks() + partialTicks) * -60.0f;
		matrixStack.mulPose(Axis.XP.rotationDegrees(90.0F));
		float pitch = Mth.lerp(partialTicks, entity.xRotO, entity.getXRot());
		if (pitch > 45 || pitch < -45) {
			matrixStack.mulPose(Axis.YP.rotationDegrees(90.0F));
		}
		if (entity.getAirTicks() > 0) {
			matrixStack.mulPose(Axis.ZP.rotationDegrees(spinRotation));
		}
		matrixStack.translate(0.0F, -0.195F, 0.0F);
		ItemRenderer itemRenderer = Minecraft.getInstance().getItemRenderer();
		itemRenderer.renderStatic(entity.weaponItem, ItemDisplayContext.GROUND, packedLight, OverlayTexture.NO_OVERLAY, matrixStack, buffer, entity.level(), entity.getId());
		matrixStack.popPose();
		super.render(entity, entityYaw, partialTicks, matrixStack, buffer, packedLight);
	}

	@Override
	public ResourceLocation getTextureLocation(ShinemerangProjectileEntity entity) {
		return TextureAtlas.LOCATION_BLOCKS;
	}

	@Override
	public boolean shouldRender(ShinemerangProjectileEntity pLivingEntity, Frustum pCamera, double pCamX, double pCamY, double pCamZ) {
		return super.shouldRender(pLivingEntity, pCamera, pCamX, pCamY, pCamZ);
	}
}
