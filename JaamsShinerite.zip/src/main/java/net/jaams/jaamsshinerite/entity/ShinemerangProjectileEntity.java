
package net.jaams.jaamsshinerite.entity;

import org.jetbrains.annotations.NotNull;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.network.PlayMessages;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.entity.IEntityAdditionalSpawnData;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.Advancement;

import net.jaams.jaamsshinerite.init.JaamsShineriteModItems;
import net.jaams.jaamsshinerite.init.JaamsShineriteModEntities;
import net.jaams.jaamsshinerite.dyeable.IDyeableItem;
import net.jaams.jaamsshinerite.configuration.JaamsShineriteCommonConfiguration;

import javax.annotation.Nullable;

import java.util.UUID;
import java.util.List;
import java.util.ArrayList;

public class ShinemerangProjectileEntity extends AbstractArrow implements IEntityAdditionalSpawnData {
	public ItemStack weaponItem;
	public float weaponDamage;
	private static final EntityDataAccessor<Boolean> ID_FOIL = SynchedEntityData.defineId(ShinemerangProjectileEntity.class, EntityDataSerializers.BOOLEAN);
	SoundEvent hit = ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("jaams_shinerite:shinemerang_hit"));
	SoundEvent ground = ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("jaams_shinerite:shinemerang_ground"));
	private boolean dealtDamage;
	private int bubbleTime = 0;
	private int airTicks = 0;
	private double boomerangRange = 3.0D;
	private int entitiesMountedCount = 0;
	private boolean hasBeenPickedUp = false;
	private boolean isReturning;
	private Vec3 initialPosition;
	private final List<Entity> hitEntities = new ArrayList<>();
	@Nullable
	private BlockState lastState;

	public ShinemerangProjectileEntity(PlayMessages.SpawnEntity packet, Level world) {
		super(JaamsShineriteModEntities.SHINEMERANG_PROJECTILE.get(), world);
		this.weaponItem = new ItemStack(JaamsShineriteModItems.SHINEMERANG.get());
	}

	public ShinemerangProjectileEntity(EntityType<? extends ShinemerangProjectileEntity> type, Level world) {
		super(type, world);
		this.weaponItem = new ItemStack(JaamsShineriteModItems.SHINEMERANG.get());
	}

	public ShinemerangProjectileEntity(EntityType<? extends ShinemerangProjectileEntity> type, double x, double y, double z, Level world) {
		super(type, x, y, z, world);
		this.weaponItem = new ItemStack(JaamsShineriteModItems.SHINEMERANG.get());
	}

	public ShinemerangProjectileEntity(EntityType<? extends ShinemerangProjectileEntity> type, LivingEntity entity, Level world) {
		super(type, entity, world);
		this.weaponItem = new ItemStack(JaamsShineriteModItems.SHINEMERANG.get());
	}

	public ShinemerangProjectileEntity(Level world, LivingEntity thrower, ItemStack weaponItem) {
		super(JaamsShineriteModEntities.SHINEMERANG_PROJECTILE.get(), thrower, world);
		this.weaponItem = weaponItem;
		this.setOwner(thrower);
	}

	@Override
	protected void defineSynchedData() {
		super.defineSynchedData();
		this.entityData.define(ID_FOIL, false);
	}

	private void applyItemData(ItemStack stack) {
		this.entityData.set(ID_FOIL, stack.hasFoil());
	}

	@Override
	public void readAdditionalSaveData(CompoundTag tag) {
		super.readAdditionalSaveData(tag);
		if (tag.contains("Weapon", 10)) {
			this.weaponItem = ItemStack.of(tag.getCompound("Weapon"));
		}
		this.dealtDamage = tag.getBoolean("DealtDamage");
		this.inGround = tag.getBoolean("InGround");
		this.boomerangRange = tag.getDouble("BoomerangRange");
		this.entitiesMountedCount = tag.getInt("EntitiesMountedCount");
		this.hasBeenPickedUp = tag.getBoolean("HasBeenPickedUp");
		this.isReturning = tag.getBoolean("IsReturning");
		if (tag.contains("InitialPosX") && tag.contains("InitialPosY") && tag.contains("InitialPosZ")) {
			this.initialPosition = new Vec3(tag.getDouble("InitialPosX"), tag.getDouble("InitialPosY"), tag.getDouble("InitialPosZ"));
		}
		ListTag hitEntitiesList = tag.getList("HitEntities", 10);
		for (int i = 0; i < hitEntitiesList.size(); i++) {
			CompoundTag entityTag = hitEntitiesList.getCompound(i);
			UUID entityUUID = entityTag.getUUID("UUID");
			Entity entity = ((ServerLevel) this.level()).getEntity(entityUUID);
			if (entity != null) {
				this.hitEntities.add(entity);
			}
		}
	}

	@Override
	public void addAdditionalSaveData(CompoundTag tag) {
		super.addAdditionalSaveData(tag);
		tag.put("Weapon", this.weaponItem.save(new CompoundTag()));
		tag.putBoolean("DealtDamage", this.dealtDamage);
		tag.putBoolean("InGround", this.inGround);
		tag.putDouble("BoomerangRange", this.boomerangRange);
		tag.putInt("EntitiesMountedCount", this.entitiesMountedCount);
		tag.putBoolean("HasBeenPickedUp", this.hasBeenPickedUp);
		tag.putBoolean("IsReturning", this.isReturning);
		if (this.initialPosition != null) {
			tag.putDouble("InitialPosX", this.initialPosition.x);
			tag.putDouble("InitialPosY", this.initialPosition.y);
			tag.putDouble("InitialPosZ", this.initialPosition.z);
		}
		ListTag hitEntitiesList = new ListTag();
		for (Entity entity : this.hitEntities) {
			CompoundTag entityTag = new CompoundTag();
			entityTag.putUUID("UUID", entity.getUUID());
			hitEntitiesList.add(entityTag);
		}
		tag.put("HitEntities", hitEntitiesList);
	}

	@Override
	public void writeSpawnData(FriendlyByteBuf buffer) {
		buffer.writeItem(this.weaponItem);
	}

	@Override
	public void readSpawnData(FriendlyByteBuf additionalData) {
		this.weaponItem = additionalData.readItem();
	}

	@Override
	public Packet<ClientGamePacketListener> getAddEntityPacket() {
		return NetworkHooks.getEntitySpawningPacket(this);
	}

	@Override
	protected @NotNull ItemStack getPickupItem() {
		ItemStack itemStack = this.weaponItem.copy();
		itemStack.setCount(1);
		return itemStack;
	}

	@Override
	public void onHitBlock(BlockHitResult blockHitResult) {
		this.lastState = this.level().getBlockState(blockHitResult.getBlockPos());
		Vec3 vec3 = blockHitResult.getLocation().subtract(this.getX(), this.getY(), this.getZ());
		this.setDeltaMovement(vec3);
		Vec3 vec31 = vec3.normalize().scale((double) 0.05F);
		this.setPosRaw(this.getX() - vec31.x, this.getY() - vec31.y, this.getZ() - vec31.z);
		this.shakeTime = 7;
		this.setCritArrow(false);
		this.inGround = true;
		this.setPierceLevel((byte) 0);
		this.setShotFromCrossbow(false);
		BlockState blockstate = this.level().getBlockState(blockHitResult.getBlockPos());
		blockstate.onProjectileHit(this.level(), blockstate, blockHitResult, this);
		this.playSound(ground, 0.5F, 1.0F);
		if (!level().isClientSide) {
			BlockState state = level().getBlockState(blockHitResult.getBlockPos());
			((ServerLevel) level()).sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, state).setPos(blockHitResult.getBlockPos()), getX(), getY(), getZ(), 6, 0.1d, 0.1d, 0.1d, 0.05d);
		}
		if (this.isReturning) {
			this.inGround = true;
			setNoGravity(false);
			this.isReturning = false;
			this.stopRidingEntities();
		} else {
			if (isNoGravity()) {
				this.isReturning = true;
				this.inGround = false;
			}
		}
	}

	protected SoundEvent getDefaultHitGroundSoundEvent() {
		return SoundEvents.TRIDENT_HIT_GROUND;
	}

	@Override
	protected void doPostHurtEffects(LivingEntity entity) {
		super.doPostHurtEffects(entity);
		if (!entity.equals(this.getOwner()) && !entity.hasEffect(MobEffects.GLOWING)) {
			if (!level().isClientSide && Math.random() <= 0.6) {
				entity.addEffect(new MobEffectInstance(MobEffects.GLOWING, 60, 0, false, false, true));
				Entity owner = this.getOwner();
				if (owner instanceof LivingEntity livingOwner && livingOwner instanceof ServerPlayer _player) {
					Advancement _adv = _player.server.getAdvancements().getAdvancement(new ResourceLocation("jaams_glowerite:shineand_shoot_advancement"));
					if (_adv != null) {
						AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
						if (!_ap.isDone()) {
							for (String criteria : _ap.getRemainingCriteria()) {
								_player.getAdvancements().award(_adv, criteria);
							}
						}
					}
				}
			}
		}
		if (entity != this.getOwner()) {
			this.isReturning = true;
		}
	}

	@Override
	protected void onHitEntity(EntityHitResult entityHitResult) {
		Entity entity = entityHitResult.getEntity();
		if (!this.level().isClientSide) {
			if (this.isReturning && entity == this.getOwner()) {
				return;
			}
			if (entity == this.getOwner()) {
				return;
			}
			long hitCount = hitEntities.stream().filter(e -> e == entity).count();
			if (this.isReturning && (hitCount >= 2 || (entity instanceof Player && ((Player) entity).isCreative()))) {
				return;
			}
			if (!(entity instanceof LivingEntity)) {
				this.setDeltaMovement(this.getDeltaMovement().multiply(-0.02D, -0.2D, -0.02D));
				entity.hurt(this.damageSources().generic(), (float) 10);
				this.isReturning = true;
			}
			float damageMultiplier = (float) Math.pow(0.5, hitCount);
			float f = (0.0F + this.weaponDamage) * damageMultiplier;
			if (entity instanceof LivingEntity livingEntity) {
				f += EnchantmentHelper.getDamageBonus(this.weaponItem, livingEntity.getMobType());
			}
			Entity owner = this.getOwner();
			DamageSource damagesource = this.damageSources().trident(this, (Entity) (owner == null ? this : owner));
			this.dealtDamage = true;
			int fireAspectLevel = EnchantmentHelper.getItemEnchantmentLevel(Enchantments.FIRE_ASPECT, this.weaponItem);
			boolean hasFireAspect = fireAspectLevel > 0;
			int knockbackLevel = EnchantmentHelper.getItemEnchantmentLevel(Enchantments.KNOCKBACK, this.weaponItem);
			boolean hasKnockback = knockbackLevel > 0;
			if (entity instanceof LivingEntity livingEntity && entity != this.getOwner()) {
				if (hasFireAspect) {
					livingEntity.setSecondsOnFire(fireAspectLevel * 4);
				}
				if (entity.isPushable()) {
					double knockbackStrength = 0.5;
					if (hasKnockback) {
						knockbackStrength += knockbackLevel * 0.5;
					}
					if (this.isReturning) {
						knockbackStrength *= 2;
					}
					double knockbackResistance = livingEntity.getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE).getValue();
					knockbackStrength *= (1.0 - knockbackResistance);
					Vec3 knockbackDirection = this.getDeltaMovement().normalize();
					livingEntity.push(knockbackDirection.x * knockbackStrength, 0.1D, knockbackDirection.z * knockbackStrength);
				}
			}
			if (entity.hurt(damagesource, f)) {
				if (entity.getType() == EntityType.ENDERMAN) {
					return;
				}
				if (entity instanceof LivingEntity) {
					LivingEntity livingEntity = (LivingEntity) entity;
					if (owner instanceof LivingEntity) {
						EnchantmentHelper.doPostHurtEffects(livingEntity, owner);
						EnchantmentHelper.doPostDamageEffects((LivingEntity) owner, livingEntity);
					}
					this.doPostHurtEffects(livingEntity);
				}
			}
			if (this.isReturning) {
				hitEntities.add(entity);
				this.setDeltaMovement(this.getDeltaMovement().multiply(-0.5D, -0.5D, -0.5D));
			}
			if (entity instanceof LivingEntity) {
				entity.invulnerableTime = 0;
			}
			if (this.weaponItem.getItem() instanceof IDyeableItem dyeableItem && dyeableItem.hasColor(this.weaponItem)) {
				int color = dyeableItem.getColor(this.weaponItem);
				float red = (color >> 16 & 255) / 255.0F;
				float green = (color >> 8 & 255) / 255.0F;
				float blue = (color & 255) / 255.0F;
				for (int i = 0; i < 20; i++) {
					double speedX = (this.random.nextDouble() - 0.5) * 0.2;
					double speedY = (this.random.nextDouble() - 0.5) * 0.2;
					double speedZ = (this.random.nextDouble() - 0.5) * 0.2;
					this.level().addParticle(new DustParticleOptions(new Vec3(red, green, blue).toVector3f(), 1.0F), this.getX(), this.getY(), this.getZ(), speedX, speedY, speedZ);
				}
			}
			this.playSound(hit, 1.0F, 1.0F);
		}
	}

	public int getAirTicks() {
		return airTicks;
	}

	@Override
	public void tick() {
		super.tick();
		if (this.tickCount == 1) {
			setNoGravity(true);
		}
		if (this.inGround) {
			airTicks = 0;
		} else {
			airTicks++;
		}
		if (this.level().isClientSide && this.isInWater() && !this.inGround) {
			bubbleTime++;
			if (bubbleTime <= 200) {
				this.level().addParticle(ParticleTypes.BUBBLE, this.getX(), this.getY(), this.getZ(), 0.0D, 0.0D, 0.0D);
			}
		} else {
			bubbleTime = 0;
		}
		if (this.level().isClientSide && !this.isInWater() && this.random.nextInt(5) == 0 && !this.inGround) {
			this.level().addParticle(ParticleTypes.FIREWORK, this.getX(), this.getY(), this.getZ(), 0.0D, 0.0D, 0.0D);
			if (this.weaponItem.getItem() instanceof IDyeableItem dyeableItem && dyeableItem.hasColor(this.weaponItem)) {
				int color = dyeableItem.getColor(this.weaponItem);
				float red = (color >> 16 & 255) / 255.0F;
				float green = (color >> 8 & 255) / 255.0F;
				float blue = (color & 255) / 255.0F;
				this.level().addParticle(new DustParticleOptions(new Vec3(red, green, blue).toVector3f(), 1.0F), this.getX(), this.getY(), this.getZ(), 0.0D, 0.0D, 0.0D);
			}
		}
		if (this.inGroundTime > 4) {
			this.dealtDamage = true;
		}
		if (JaamsShineriteCommonConfiguration.DROPASITEMLAVA.get() == true) {
			if (this.isInLava()) {
				dropAsItem();
				this.discard();
			}
		}
		if (!level().isClientSide) {
			if (initialPosition == null) {
				initialPosition = this.position();
			}
			if (this.position().distanceTo(initialPosition) >= boomerangRange && !this.inGround) {
				this.isReturning = true;
			}
			if (this.isReturning) {
				Entity owner = this.getOwner();
				if (owner != null && owner.isAlive() && !owner.isSpectator()) {
					this.returnToOwner();
				} else {
					setNoGravity(false);
					this.isReturning = false;
				}
			}
		}
		if (this.inGround && this.getOwner() instanceof Mob mobOwner) {
			double pickupRange = 1.5D;
			if (this.position().distanceTo(mobOwner.position()) <= pickupRange) {
				ItemStack pickupItemStack = this.weaponItem.copy();
				pickupItemStack.setCount(1);
				boolean canPickup = (mobOwner.getItemInHand(InteractionHand.MAIN_HAND).isEmpty() || mobOwner.getItemInHand(InteractionHand.OFF_HAND).isEmpty()
						|| (mobOwner.getItemInHand(InteractionHand.MAIN_HAND).is(pickupItemStack.getItem()) && mobOwner.getItemInHand(InteractionHand.MAIN_HAND).getCount() < mobOwner.getItemInHand(InteractionHand.MAIN_HAND).getMaxStackSize())
						|| (mobOwner.getItemInHand(InteractionHand.OFF_HAND).is(pickupItemStack.getItem()) && mobOwner.getItemInHand(InteractionHand.OFF_HAND).getCount() < mobOwner.getItemInHand(InteractionHand.OFF_HAND).getMaxStackSize()));
				if (canPickup && tryPickup(mobOwner)) {
					this.discard();
				}
			}
		}
	}

	private void returnToOwner() {
		Entity owner = this.getOwner();
		if (owner != null && owner.isAlive() && !owner.isSpectator() && this.ownedBy(owner)) {
			Vec3 ownerPos = owner.position().add(0, owner.getEyeHeight() * 0.85, 0);
			Vec3 direction = ownerPos.subtract(this.position()).normalize();
			Vec3 currentMotion = this.getDeltaMovement();
			double returnSpeed = this.isUnderWater() ? 0.4 : 0.7;
			Vec3 newMotion = direction.scale(returnSpeed);
			this.setDeltaMovement(newMotion);
			double pickupDistance = 1.5D;
			if (this.position().distanceTo(ownerPos) <= pickupDistance) {
				if (owner instanceof Player) {
					Player player = (Player) owner;
					this.playerPickupInAir(player);
					this.stopRidingEntities();
					this.entitiesMountedCount = 0;
				}
			}
			List<Entity> entitiesInRange = this.level().getEntities(this, this.getBoundingBox().inflate(0.3D), entity -> entity instanceof ItemEntity || entity instanceof ExperienceOrb);
			for (Entity entity : entitiesInRange) {
				if (!entity.isPassenger() && this.entitiesMountedCount < 3) {
					entity.startRiding(this, true);
					this.entitiesMountedCount++;
					entity.setGlowingTag(true);
				}
			}
		} else {
			this.isReturning = false;
			this.setNoGravity(false);
			this.stopRidingEntities();
			this.entitiesMountedCount = 0;
		}
	}

	private void stopRidingEntities() {
		for (Entity passenger : new ArrayList<>(this.getPassengers())) {
			passenger.setGlowingTag(false);
			passenger.stopRiding();
		}
		this.entitiesMountedCount = 0;
	}

	@Override
	public void remove(RemovalReason reason) {
		stopRidingEntities();
		super.remove(reason);
	}

	@Override
	public void removePassenger(Entity passenger) {
		super.removePassenger(passenger);
		passenger.setGlowingTag(false);
	}

	@Override
	public double getPassengersRidingOffset() {
		return 0.0d;
	}

	public void playerPickupInAir(Player player) {
		if (!this.level().isClientSide && this.isReturning && !this.inGround && !this.hasBeenPickedUp) {
			if (this.tryPickup(player)) {
				player.take(this, 1);
				this.hasBeenPickedUp = true;
				this.discard();
			} else {
				player.take(this, 1);
				this.discard();
			}
		}
	}

	@Override
	public void playerTouch(Player player) {
		if (!this.level().isClientSide && !this.isReturning && this.inGround && this.shakeTime <= 0 && !this.hasBeenPickedUp) {
			if (this.tryPickup(player)) {
				player.take(this, 1);
				this.hasBeenPickedUp = true;
				this.discard();
			}
		}
	}

	public void setBoomerangRange(double range) {
		this.boomerangRange = range;
	}

	int life = 0;

	@Override
	protected void tickDespawn() {
		life++;
		if (life >= JaamsShineriteCommonConfiguration.SHINEMERANGDESPAWN.get()) {
			if (JaamsShineriteCommonConfiguration.DROPASITEM.get() && this.pickup != AbstractArrow.Pickup.CREATIVE_ONLY) {
				dropAsItem();
			} else {
				if (!level().isClientSide) {
					ItemStack itemStack = this.weaponItem.copy();
					if (!itemStack.isEmpty()) {
						((ServerLevel) level()).sendParticles(new ItemParticleOption(ParticleTypes.ITEM, itemStack), getX(), getY() + 0.3, getZ(), 5, 0.1d, 0.1d, 0.1d, 0.05d);
					}
				}
			}
			discard();
		}
	}

	protected void dropAsItem() {
		if (this.getOwner() instanceof ServerPlayer) {
			ItemStack itemToSpawn = this.weaponItem.copy();
			itemToSpawn.setCount(1);
			ItemEntity entityToSpawn = new ItemEntity(this.level(), this.getX(), this.getY(), this.getZ(), itemToSpawn);
			entityToSpawn.setPickUpDelay(10);
			this.level().addFreshEntity(entityToSpawn);
		}
	}

	protected boolean tryPickup(LivingEntity entity) {
		if (entity instanceof Player player) {
			return super.tryPickup(player);
		} else if (entity instanceof Mob mob) {
			ItemStack pickupItemStack = this.weaponItem.copy();
			pickupItemStack.setCount(1);
			ItemStack mainHandStack = mob.getItemInHand(InteractionHand.MAIN_HAND);
			ItemStack offHandStack = mob.getItemInHand(InteractionHand.OFF_HAND);
			if (!mainHandStack.isEmpty() && mainHandStack.is(pickupItemStack.getItem()) && mainHandStack.getCount() < mainHandStack.getMaxStackSize()) {
				mainHandStack.grow(pickupItemStack.getCount());
				return true;
			}
			if (!offHandStack.isEmpty() && offHandStack.is(pickupItemStack.getItem()) && offHandStack.getCount() < offHandStack.getMaxStackSize()) {
				offHandStack.grow(pickupItemStack.getCount());
				return true;
			}
			if (mainHandStack.isEmpty()) {
				mob.setItemInHand(InteractionHand.MAIN_HAND, pickupItemStack);
				return true;
			}
			if (offHandStack.isEmpty()) {
				mob.setItemInHand(InteractionHand.OFF_HAND, pickupItemStack);
				return true;
			}
		}
		return false;
	}

	@Override
	public int getPortalWaitTime() {
		return 72000;
	}

	public boolean isFoil() {
		return this.entityData.get(ID_FOIL);
	}

	public boolean isReturning() {
		return this.isReturning;
	}

	public float weaponDamage() {
		return this.weaponDamage;
	}

	protected float getWaterInertia() {
		return 0.99F;
	}

	@Override
	@OnlyIn(Dist.CLIENT)
	public boolean shouldRender(double x, double y, double z) {
		return true;
	}
}
