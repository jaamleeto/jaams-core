package net.jaams.jaamsshinerite.block.entity;

import org.joml.Vector3f;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.Level;
import net.minecraft.tags.FluidTags;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.Connection;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.BlockPos;

import net.jaams.jaamsshinerite.init.JaamsShineriteModBlockEntities;

public class TintableBlockEntity extends BlockEntity implements BlockEntityTicker<TintableBlockEntity> {
	private int color = -1; // Valor predeterminado de color (-1 para blanco)
	private boolean waxed = false;
	private int ticksUnderRain = 0;
	private long lastWaxParticleTime = 0;
	private int lightLevel = 0;

	public TintableBlockEntity(BlockPos pos, BlockState state) {
		super(JaamsShineriteModBlockEntities.TINTABLE.get(), pos, state);
	}

	public int getColor() {
		return this.color;
	}

	public void setColor(int color) {
		if (this.color != color) {
			this.color = color;
			setChanged();
			if (!this.level.isClientSide)
				sync();
		}
	}

	public int getLightLevel() {
		return lightLevel;
	}

	public void setLightLevel(int level) {
		if (this.lightLevel != level) {
			this.lightLevel = level;
			setChanged();
			if (!this.level.isClientSide) {
				sync(); // Sincronizar los cambios con el cliente
			}
		}
	}

	public long getLastWaxParticleTime() {
		return lastWaxParticleTime;
	}

	public void setLastWaxParticleTime(long time) {
		this.lastWaxParticleTime = time;
	}

	public void setWaxed(boolean waxed) {
		if (this.waxed != waxed) {
			this.waxed = waxed;
			setChanged();
			if (!this.level.isClientSide)
				sync();
		}
	}

	public boolean isWaxed() {
		return this.waxed;
	}

	@Override
	public void tick(Level level, BlockPos pos, BlockState state, TintableBlockEntity blockEntity) {
		if (!level.isClientSide && !waxed && color != -1 && color != 0xFFFFFF) {
			boolean isRaining = level.isRainingAt(pos.above());
			boolean hasWaterNearby = hasWaterNearby(level, pos);
			if (isRaining || hasWaterNearby) {
				ticksUnderRain++;
				if (ticksUnderRain >= 50) {
					if (color == 0xFFFFFF) {
						setColor(-1); // Restablecer a color predeterminado
					} else {
						lightenColorUnderRainOrWater();
					}
					ticksUnderRain = 0;
				}
			} else {
				ticksUnderRain = 0;
			}
		}
	}

	private boolean hasWaterNearby(Level level, BlockPos pos) {
		BlockPos[] adjacentPositions = new BlockPos[]{pos.north(), pos.south(), pos.east(), pos.west(), pos.above(), pos.below()};
		for (BlockPos adjacentPos : adjacentPositions) {
			if (level.getFluidState(adjacentPos).is(FluidTags.WATER)) {
				return true;
			}
		}
		return false;
	}

	private void lightenColorUnderRainOrWater() {
		if (color == -1)
			return;
		int red = (color >> 16) & 0xFF;
		int green = (color >> 8) & 0xFF;
		int blue = color & 0xFF;
		red = Math.min(255, red + 10);
		green = Math.min(255, green + 10);
		blue = Math.min(255, blue + 10);
		setColor((red << 16) | (green << 8) | blue);
		spawnDustParticles();
	}

	private void spawnDustParticles() {
		if (color != -1 && this.level instanceof ServerLevel serverLevel) {
			float red = ((color >> 16) & 0xFF) / 255.0f;
			float green = ((color >> 8) & 0xFF) / 255.0f;
			float blue = (color & 0xFF) / 255.0f;
			for (int i = 0; i < 10; i++) {
				double offsetX = this.level.random.nextDouble() * 0.6 - 0.3;
				double offsetY = this.level.random.nextDouble() * 0.5 + 0.25;
				double offsetZ = this.level.random.nextDouble() * 0.6 - 0.3;
				serverLevel.sendParticles(new DustParticleOptions(new Vector3f(red, green, blue), 1.0f), this.worldPosition.getX() + 0.5 + offsetX, this.worldPosition.getY() + 0.5 + offsetY, this.worldPosition.getZ() + 0.5 + offsetZ, 1, 0.0, 0.0,
						0.0, 0.0);
			}
		}
	}

	@Override
	protected void saveAdditional(CompoundTag tag) {
		super.saveAdditional(tag);
		tag.putInt("Color", this.color);
		tag.putBoolean("Waxed", this.waxed);
		tag.putInt("LightLevel", this.lightLevel); // Guardar el nivel de luz
	}

	@Override
	public void load(CompoundTag tag) {
		super.load(tag);
		if (tag.contains("Color", Tag.TAG_INT)) {
			this.color = tag.getInt("Color");
		}
		if (tag.contains("Waxed", Tag.TAG_BYTE)) {
			this.waxed = tag.getBoolean("Waxed");
		}
		if (tag.contains("LightLevel", Tag.TAG_INT)) {
			this.lightLevel = tag.getInt("LightLevel"); // Cargar el nivel de luz
		}
	}

	public void sync() {
		if (this.level != null) {
			this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), 3);
		}
	}

	@Override
	public Packet<ClientGamePacketListener> getUpdatePacket() {
		return ClientboundBlockEntityDataPacket.create(this);
	}

	@Override
	public void onDataPacket(Connection net, ClientboundBlockEntityDataPacket pkt) {
		this.load(pkt.getTag());
	}

	@Override
	public CompoundTag getUpdateTag() {
		return this.saveWithFullMetadata();
	}
}
