
package net.jaams.jaamsshinerite.block;

import org.joml.Vector3f;

import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.util.RandomSource;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.BlockPos;

import net.jaams.jaamsshinerite.item.ShinyScraperItem;
import net.jaams.jaamsshinerite.item.ShinyPaintBrushItem;
import net.jaams.jaamsshinerite.init.JaamsShineriteModBlocks;
import net.jaams.jaamsshinerite.init.JaamsShineriteModBlockEntities;
import net.jaams.jaamsshinerite.dyeable.IDyeableItem;
import net.jaams.jaamsshinerite.block.entity.TintableBlockEntity;

import javax.annotation.Nullable;

import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.Collections;

public class TintableBlock extends Block implements EntityBlock {
	public static final IntegerProperty BLOCKSTATE = IntegerProperty.create("blockstate", 0, 1);
	public static final BooleanProperty WATERLOGGED = BlockStateProperties.WATERLOGGED;

	public TintableBlock() {
		super(BlockBehaviour.Properties.of().instrument(NoteBlockInstrument.BASEDRUM).sound(SoundType.METAL).strength(5f, 6f).noOcclusion().hasPostProcess((bs, br, bp) -> true).isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(BLOCKSTATE, 0).setValue(WATERLOGGED, true));
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(BLOCKSTATE, WATERLOGGED);
	}

	@Override
	public FluidState getFluidState(BlockState state) {
		return state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(true) : super.getFluidState(state);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		FluidState fluidstate = context.getLevel().getFluidState(context.getClickedPos());
		return this.defaultBlockState().setValue(WATERLOGGED, fluidstate.getType() == Fluids.WATER);
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		BlockEntity blockEntity = worldIn.getBlockEntity(pos);
		if (blockEntity instanceof TintableBlockEntity tintableBlockEntity) {
			return tintableBlockEntity.getLightLevel(); // Bloquear la luz basado en el nivel de luz
		}
		return super.getLightBlock(state, worldIn, pos); // Devuelve el comportamiento predeterminado
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return state.getShape(world, pos);
	}

	@Override
	public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
		return new TintableBlockEntity(pos, state);
	}

	@Override
	public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
		return type == JaamsShineriteModBlockEntities.TINTABLE.get() ? (BlockEntityTicker<T>) (level1, pos, state1, blockEntity) -> {
			if (blockEntity instanceof TintableBlockEntity tintableBlockEntity) {
				tintableBlockEntity.tick(level1, pos, state1, tintableBlockEntity);
			}
		} : null;
	}

	@Override
	public void onProjectileHit(Level level, BlockState state, BlockHitResult hit, Projectile projectile) {
		super.onProjectileHit(level, state, hit, projectile);
		BlockPos pos = hit.getBlockPos();
		BlockEntity blockEntity = level.getBlockEntity(pos);
		if (blockEntity instanceof TintableBlockEntity tintableBlockEntity) {
			int color = tintableBlockEntity.getColor();
			if (color != -1 && color != 0xFFFFFF) {
				float red = (color >> 16 & 255) / 255.0F;
				float green = (color >> 8 & 255) / 255.0F;
				float blue = (color & 255) / 255.0F;
				float particleSize = 1.5f;
				int particleCount = 20;
				Vec3 hitLocation = hit.getLocation();
				for (int i = 0; i < particleCount; i++) {
					double angle = level.random.nextDouble() * 2 * Math.PI;
					double speed = level.random.nextDouble() * 0.15 + 0.05;
					double velocityX = Math.cos(angle) * speed;
					double velocityY = level.random.nextDouble() * 0.2 + 0.1;
					double velocityZ = Math.sin(angle) * speed;
					level.addParticle(new DustParticleOptions(new Vector3f(red, green, blue), particleSize), hitLocation.x(), hitLocation.y(), hitLocation.z(), velocityX, velocityY, velocityZ);
				}
			}
		}
	}

	@Override
	public boolean addRunningEffects(BlockState state, Level level, BlockPos pos, Entity entity) {
		BlockEntity blockEntity = level.getBlockEntity(pos);
		if (blockEntity instanceof TintableBlockEntity tintableBlockEntity) {
			int color = tintableBlockEntity.getColor();
			if (color != -1 && color != 0xFFFFFF) {
				float red = (color >> 16 & 255) / 255.0F;
				float green = (color >> 8 & 255) / 255.0F;
				float blue = (color & 255) / 255.0F;
				float particleSize = 1.2f;
				int particleCount = 3;
				for (int i = 0; i < particleCount; i++) {
					double velocityX = (level.random.nextDouble() - 0.5) * 0.1;
					double velocityY = level.random.nextDouble() * 0.1;
					double velocityZ = (level.random.nextDouble() - 0.5) * 0.1;
					level.addParticle(new DustParticleOptions(new Vector3f(red, green, blue), particleSize), entity.getX() + (level.random.nextDouble() - 0.5), entity.getY() + 0.1, entity.getZ() + (level.random.nextDouble() - 0.5), velocityX,
							velocityY, velocityZ);
				}
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean addLandingEffects(BlockState state1, ServerLevel level, BlockPos pos, BlockState state2, LivingEntity entity, int numberOfParticles) {
		BlockEntity blockEntity = level.getBlockEntity(pos);
		if (blockEntity instanceof TintableBlockEntity tintableBlockEntity && !level.isClientSide()) {
			int color = tintableBlockEntity.getColor();
			if (color != -1 && color != 0xFFFFFF) {
				float red = (color >> 16 & 255) / 255.0F;
				float green = (color >> 8 & 255) / 255.0F;
				float blue = (color & 255) / 255.0F;
				float particleSize = 1.5f;
				// Generar partículas justo en los pies del jugador (sobre el bloque)
				for (int i = 0; i < numberOfParticles; i++) {
					double velocityX = (level.random.nextDouble() - 0.5) * 0.1;
					double velocityY = level.random.nextDouble() * 0.1;
					double velocityZ = (level.random.nextDouble() - 0.5) * 0.1;
					// Posición en los pies del jugador con dispersión lateral en X y Z
					double offsetX = (level.random.nextDouble() - 0.5) * 0.5; // Dispersión ligera en X
					double offsetZ = (level.random.nextDouble() - 0.5) * 0.5; // Dispersión ligera en Z
					// Generar partículas justo en los pies del jugador
					level.sendParticles(new DustParticleOptions(new Vector3f(red, green, blue), particleSize), entity.getX() + offsetX, // Posición en los pies del jugador en X
							entity.getY(), // Justo en la posición de los pies del jugador
							entity.getZ() + offsetZ, // Posición en los pies del jugador en Z
							1, velocityX, velocityY, velocityZ, 0.0D);
				}
				return true;
			}
		}
		return false;
	}

	@Override
	public int getLightEmission(BlockState state, BlockGetter world, BlockPos pos) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity instanceof TintableBlockEntity tintableBlockEntity) {
			return tintableBlockEntity.getLightLevel(); // Usar el nivel de luz de la entidad del bloque
		}
		return super.getLightEmission(state, world, pos);
	}

	@Override
	public InteractionResult use(BlockState state, Level world, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
		ItemStack itemstack = player.getItemInHand(hand);
		Item item = itemstack.getItem();
		// Verifica si es una TintableBlockEntity
		if (world.getBlockEntity(pos) instanceof TintableBlockEntity blockEntity) {
			if (blockEntity.isWaxed() && (item instanceof ShinyPaintBrushItem || item instanceof DyeItem || item == Items.HONEYCOMB || item == Items.INK_SAC || item == Items.GLOW_INK_SAC)) {
				long currentTime = world.getGameTime(); // Tiempo actual del juego en ticks
				if (currentTime - blockEntity.getLastWaxParticleTime() >= 30) { // Verifica si han pasado 20 ticks (1 segundo)
					generateWaxParticles(world, pos, world.random);
					blockEntity.setLastWaxParticleTime(currentTime); // Actualiza el tiempo de la última generación de partículas
				}
				return InteractionResult.CONSUME;
			}
			// Interacción con Polvo Luminoso (Glowstone Dust)
			if (item == Items.GLOWSTONE_DUST) {
				// Aumentar el nivel de luz, máximo de 15
				int currentLightLevel = blockEntity.getLightLevel();
				if (currentLightLevel < 15) {
					blockEntity.setLightLevel(currentLightLevel + 1); // Aumenta el nivel de luz
					world.setBlock(pos, state, 3); // Notificar el cambio de estado
					world.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_PLACE, SoundSource.BLOCKS, 1.0F, 1.0F); // Sonido de usar polvo luminoso
					if (!player.isCreative()) {
						itemstack.shrink(1); // Reducir el stack del polvo luminoso si no está en modo creativo
					}
					return InteractionResult.SUCCESS;
				} else {
					return InteractionResult.PASS; // No hacer nada si ya está al máximo nivel de luz
				}
			}
			if (blockEntity.isWaxed()) {
				if (item instanceof ShinyScraperItem) {
					blockEntity.setWaxed(false);
					world.playSound(null, pos, SoundEvents.AXE_WAX_OFF, SoundSource.BLOCKS, 1.0F, 1.0F);
					if (!player.isCreative()) {
						reduceItemStack(player, itemstack);
					}
					generateWaxRemovalParticles(world, pos, world.random);
					return InteractionResult.SUCCESS;
				}
				return InteractionResult.PASS;
			}
			int blockColor = blockEntity.getColor();
			if (item instanceof ShinyPaintBrushItem dyeableItem) {
				if (dyeableItem.hasColor(itemstack)) {
					int color = dyeableItem.getColor(itemstack);
					if (color == blockColor || (color == DyeColor.BLACK.getTextColor() && blockColor == lightenColor(DyeColor.BLACK.getTextColor()))) {
						return InteractionResult.PASS; // No tiñe si ya tiene el color
					}
					if (color == DyeColor.BLACK.getTextColor()) {
						color = lightenColor(color);
					}
					applyDye(world, pos, state, color);
					if (!player.isCreative()) {
						reduceItemStack(player, itemstack);
					}
					return InteractionResult.SUCCESS;
				}
			} else if (item instanceof DyeItem dyeItem) {
				int color = dyeItem.getDyeColor().getTextColor();
				if (color == blockColor || (dyeItem.getDyeColor() == DyeColor.BLACK && blockColor == lightenColor(DyeColor.BLACK.getTextColor()))) {
					return InteractionResult.PASS;
				}
				if (dyeItem.getDyeColor() == DyeColor.BLACK) {
					color = lightenColor(color);
				}
				applyDye(world, pos, state, color);
				if (!player.isCreative()) {
					reduceItemStack(player, itemstack);
				}
				return InteractionResult.SUCCESS;
			} else if (item instanceof ShinyScraperItem && blockColor != -1 && blockColor != 0xFFFFFF) {
				applyDye(world, pos, state, -1); // Elimina el tinte aplicando el color -1
				if (!player.isCreative()) {
					reduceItemStack(player, itemstack);
				}
				return InteractionResult.SUCCESS;
			} else if (item == Items.HONEYCOMB) {
				blockEntity.setWaxed(true);
				if (!player.isCreative()) {
					reduceItemStack(player, itemstack);
				}
				generateWaxParticles(world, pos, world.random);
				world.playSound(null, pos, SoundEvents.HONEYCOMB_WAX_ON, SoundSource.BLOCKS, 1.0F, 1.0F);
				return InteractionResult.SUCCESS;
			}
		}
		// Verifica si es un HoeItem y alterna el BLOCKSTATE
		if (item == Items.INK_SAC && state.getValue(TintableBlock.BLOCKSTATE) != 1) {
			world.setBlock(pos, state.setValue(TintableBlock.BLOCKSTATE, 1), 3);
			generateInkParticles(world, pos, new Vector3f(0.0f, 0.0f, 0.0f)); // Partículas negras
			world.playSound(null, pos, SoundEvents.INK_SAC_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
			return InteractionResult.SUCCESS;
		} else if (item == Items.GLOW_INK_SAC && state.getValue(TintableBlock.BLOCKSTATE) != 0) {
			world.setBlock(pos, state.setValue(TintableBlock.BLOCKSTATE, 0), 3);
			generateInkParticles(world, pos, new Vector3f(0.0f, 1.0f, 1.0f)); // Partículas azul celeste
			world.playSound(null, pos, SoundEvents.GLOW_INK_SAC_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
			return InteractionResult.SUCCESS;
		}
		return InteractionResult.PASS;
	}

	private void generateInkParticles(Level world, BlockPos pos, Vector3f color) {
		if (world instanceof ServerLevel serverLevel) {
			RandomSource random = serverLevel.random;
			int numParticles = 50; // Aumentar el número de partículas
			double particleRadius = 0.5; // Radio de generación alrededor del bloque
			float particleSize = 1.5f;
			for (int i = 0; i < numParticles; i++) {
				double angle = random.nextDouble() * 2 * Math.PI;
				double xOffset = Math.cos(angle) * particleRadius;
				double zOffset = Math.sin(angle) * particleRadius;
				double yOffset = (random.nextDouble() - 0.5) * 1.6; // Rango ajustado de -0.8 a 0.8
				// Añadir velocidades aleatorias para que las partículas se muevan
				double xSpeed = (random.nextDouble() - 0.5) * 0.1;
				double ySpeed = (random.nextDouble() - 0.5) * 0.1; // Movimiento ascendente y descendente
				double zSpeed = (random.nextDouble() - 0.5) * 0.1;
				// Generar las partículas con el desplazamiento y el movimiento
				serverLevel.sendParticles(new DustParticleOptions(color, particleSize), pos.getX() + 0.5 + xOffset, // Centrar en el bloque y añadir desplazamiento lateral
						pos.getY() + 0.5 + yOffset, // Ajustar el rango vertical
						pos.getZ() + 0.5 + zOffset, // Centrar en el bloque y añadir desplazamiento lateral
						1, xSpeed, ySpeed, zSpeed, 0.0); // Añadir movimiento a las partículas
			}
		}
	}

	private void reduceItemStack(Player player, ItemStack itemstack) {
		if (itemstack.isDamageableItem() && itemstack.getMaxStackSize() == 1) {
			itemstack.hurtAndBreak(1, player, (p) -> p.broadcastBreakEvent(player.getUsedItemHand()));
		} else {
			itemstack.shrink(1);
		}
	}

	private void generateWaxParticles(Level world, BlockPos pos, RandomSource random) {
		if (!world.isClientSide) {
			int numParticles = 20; // Número de partículas
			double spread = 0.65; // Extensión de partículas hacia los bordes del bloque
			double offsetFromCenter = 0.65; // Para garantizar que las partículas se generen en la superficie
			double centerX = pos.getX() + 0.5;
			double centerY = pos.getY() + 0.5;
			double centerZ = pos.getZ() + 0.5;
			for (int i = 0; i < numParticles; i++) {
				// Selecciona una cara aleatoria (0 = X, 1 = Y, 2 = Z)
				int axis = random.nextInt(3);
				// Desplazamiento para que las partículas se generen en los lados
				double xOffset = axis == 0 ? (random.nextBoolean() ? offsetFromCenter : -offsetFromCenter) : (random.nextDouble() - 0.5) * spread;
				double yOffset = axis == 1 ? (random.nextBoolean() ? offsetFromCenter : -offsetFromCenter) : (random.nextDouble() - 0.5) * spread;
				double zOffset = axis == 2 ? (random.nextBoolean() ? offsetFromCenter : -offsetFromCenter) : (random.nextDouble() - 0.5) * spread;
				// Velocidades aleatorias para las partículas
				double xSpeed = (random.nextDouble() - 0.5) * 0.02;
				double ySpeed = (random.nextDouble() - 0.5) * 0.02;
				double zSpeed = (random.nextDouble() - 0.5) * 0.02;
				// Generar partículas en los bordes de las caras del bloque
				((ServerLevel) world).sendParticles(ParticleTypes.WAX_ON, centerX + xOffset, centerY + yOffset, centerZ + zOffset, 1, xSpeed, ySpeed, zSpeed, 0.25);
			}
		}
	}

	private void generateWaxRemovalParticles(Level world, BlockPos pos, RandomSource random) {
		if (!world.isClientSide) {
			int numParticles = 20; // Número de partículas
			double spread = 0.65; // Extensión de partículas hacia los bordes del bloque
			double offsetFromCenter = 0.65; // Para garantizar que las partículas se generen en la superficie
			double centerX = pos.getX() + 0.5;
			double centerY = pos.getY() + 0.5;
			double centerZ = pos.getZ() + 0.5;
			for (int i = 0; i < numParticles; i++) {
				// Selecciona una cara aleatoria (0 = X, 1 = Y, 2 = Z)
				int axis = random.nextInt(3);
				// Desplazamiento para que las partículas se generen en los lados
				double xOffset = axis == 0 ? (random.nextBoolean() ? offsetFromCenter : -offsetFromCenter) : (random.nextDouble() - 0.5) * spread;
				double yOffset = axis == 1 ? (random.nextBoolean() ? offsetFromCenter : -offsetFromCenter) : (random.nextDouble() - 0.5) * spread;
				double zOffset = axis == 2 ? (random.nextBoolean() ? offsetFromCenter : -offsetFromCenter) : (random.nextDouble() - 0.5) * spread;
				// Velocidades aleatorias para las partículas
				double xSpeed = (random.nextDouble() - 0.5) * 0.02;
				double ySpeed = (random.nextDouble() - 0.5) * 0.02;
				double zSpeed = (random.nextDouble() - 0.5) * 0.02;
				// Generar partículas en los bordes de las caras del bloque
				((ServerLevel) world).sendParticles(ParticleTypes.WAX_OFF, centerX + xOffset, centerY + yOffset, centerZ + zOffset, 1, xSpeed, ySpeed, zSpeed, 0.25);
			}
		}
	}

	private int lightenColor(int color) {
		int red = (color >> 16) & 0xFF;
		int green = (color >> 8) & 0xFF;
		int blue = color & 0xFF;
		red = Math.min(255, red + 30);
		green = Math.min(255, green + 30);
		blue = Math.min(255, blue + 30);
		return (red << 16) | (green << 8) | blue;
	}

	private void applyDye(Level world, BlockPos pos, BlockState state, int color) {
		if (world.getBlockEntity(pos) instanceof TintableBlockEntity blockEntity) {
			blockEntity.setColor(color); // Almacenar el color directamente en la BlockEntity
			world.sendBlockUpdated(pos, state, state, 3); // Notificar actualización de bloque
			world.playSound(null, pos, SoundEvents.DYE_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
			float[] colorComponents = new float[]{(color >> 16 & 255) / 255.0F, (color >> 8 & 255) / 255.0F, (color & 255) / 255.0F};
			int numParticles = 50; // Aumentar el número de partículas
			double particleRadius = 0.5; // Radio de generación alrededor del bloque
			for (int i = 0; i < numParticles; i++) {
				double angle = world.random.nextDouble() * 2 * Math.PI;
				double xOffset = Math.cos(angle) * particleRadius;
				double zOffset = Math.sin(angle) * particleRadius;
				// Generar el yOffset para que se incluyan partículas tanto por encima como por debajo del bloque
				double yOffset = (world.random.nextDouble() - 0.5) * 1.6; // Ajuste el rango para que sea de -0.8 a 0.8
				// Generar velocidades aleatorias para las partículas
				double xSpeed = (world.random.nextDouble() - 0.5) * 0.1;
				double ySpeed = (world.random.nextDouble() - 0.5) * 0.1; // También se puede mover hacia arriba y hacia abajo
				double zSpeed = (world.random.nextDouble() - 0.5) * 0.1;
				// Generar las partículas alrededor del bloque, incluyendo por encima y por debajo
				world.addParticle(new DustParticleOptions(new Vector3f(colorComponents[0], colorComponents[1], colorComponents[2]), 1.0F), pos.getX() + 0.5 + xOffset, // Centrar en el bloque y añadir desplazamiento lateral
						pos.getY() + 0.5 + yOffset, // Ajustar para que abarque desde abajo hasta arriba del bloque
						pos.getZ() + 0.5 + zOffset, // Centrar en el bloque y añadir desplazamiento lateral
						xSpeed, ySpeed, zSpeed);
			}
		}
	}

	@Override
	public float[] getBeaconColorMultiplier(BlockState state, LevelReader world, BlockPos pos, BlockPos beaconPos) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity instanceof TintableBlockEntity tintableBlockEntity) {
			int color = tintableBlockEntity.getColor();
			return new float[]{(color >> 16 & 255) / 255.0F, (color >> 8 & 255) / 255.0F, (color & 255) / 255.0F};
		}
		return new float[]{1f, 1f, 1f};
	}

	@Override
	public List<ItemStack> getDrops(BlockState state, LootParams.Builder builder) {
		BlockEntity blockEntity = builder.getOptionalParameter(LootContextParams.BLOCK_ENTITY);
		if (blockEntity instanceof TintableBlockEntity tintableBlockEntity) {
			ItemStack stack = new ItemStack(this);
			int color = tintableBlockEntity.getColor();
			if (stack.getItem() instanceof IDyeableItem dyeableItem) {
				dyeableItem.setColor(stack, color);
			}
			if (tintableBlockEntity.isWaxed()) {
				stack.getOrCreateTag().putBoolean("Waxed", true);
			}
			int blockStateValue = state.getValue(TintableBlock.BLOCKSTATE);
			stack.getOrCreateTag().putInt("BlockState", blockStateValue);
			stack.getOrCreateTag().putInt("CustomModelData", blockStateValue);
			return Collections.singletonList(stack);
		}
		return super.getDrops(state, builder);
	}

	@Override
	public ItemStack getCloneItemStack(BlockGetter world, BlockPos pos, BlockState state) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity instanceof TintableBlockEntity tintableBlockEntity) {
			ItemStack stack = new ItemStack(this);
			// Obtener y aplicar el color al ítem, si es tintable
			int color = tintableBlockEntity.getColor();
			if (stack.getItem() instanceof IDyeableItem dyeableItem) {
				dyeableItem.setColor(stack, color);
			}
			// Marcar el ítem como encerado si aplica
			if (tintableBlockEntity.isWaxed()) {
				stack.getOrCreateTag().putBoolean("Waxed", true);
			}
			// Guardar el estado del bloque en el NBT y establecer CustomModelData
			int blockStateValue = state.getValue(TintableBlock.BLOCKSTATE);
			stack.getOrCreateTag().putInt("BlockState", blockStateValue);
			// Aquí puedes mapear `blockStateValue` a un valor de CustomModelData si lo deseas
			stack.getOrCreateTag().putInt("CustomModelData", blockStateValue);
			return stack;
		}
		return super.getCloneItemStack(world, pos, state);
	}

	@Override
	public boolean triggerEvent(BlockState state, Level world, BlockPos pos, int eventID, int eventParam) {
		super.triggerEvent(state, world, pos, eventID, eventParam);
		BlockEntity blockEntity = world.getBlockEntity(pos);
		return blockEntity == null ? false : blockEntity.triggerEvent(eventID, eventParam);
	}

	private final Map<BlockPos, CompoundTag> stateMap = new HashMap<>();

	@Override
	public void onRemove(BlockState state, Level world, BlockPos pos, BlockState newState, boolean isMoving) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (!world.isClientSide && isMoving) {
			if (blockEntity instanceof TintableBlockEntity tintableBlockEntity) {
				// Guarda el estado completo del BlockEntity antes de mover el bloque
				stateMap.put(pos, tintableBlockEntity.saveWithFullMetadata());
			}
		}
		if (blockEntity instanceof TintableBlockEntity tintableBlockEntity && !world.isClientSide) {
			int color = tintableBlockEntity.getColor();
			if (color != -1 && color != 0xFFFFFF && world instanceof ServerLevel serverLevel) {
				float[] colorComponents = new float[]{(color >> 16 & 255) / 255.0F, (color >> 8 & 255) / 255.0F, (color & 255) / 255.0F};
				int numParticles = 40; // Número de partículas
				double particleRadius = 0.5; // Radio de generación alrededor del bloque
				float particleSize = 1.0F; // Ajustable según lo que necesites
				for (int i = 0; i < numParticles; i++) {
					double angle = world.random.nextDouble() * 2 * Math.PI;
					double xOffset = Math.cos(angle) * particleRadius;
					double zOffset = Math.sin(angle) * particleRadius;
					double yOffset = (world.random.nextDouble() - 0.5) * 1.6; // Rango ajustado de -0.8 a 0.8
					double xSpeed = (world.random.nextDouble() - 0.5) * 0.1;
					double ySpeed = (world.random.nextDouble() - 0.5) * 0.1;
					double zSpeed = (world.random.nextDouble() - 0.5) * 0.1;
					serverLevel.sendParticles(new DustParticleOptions(new Vector3f(colorComponents[0], colorComponents[1], colorComponents[2]), particleSize), pos.getX() + 0.5 + xOffset, pos.getY() + 0.5 + yOffset, pos.getZ() + 0.5 + zOffset, 1,
							xSpeed, ySpeed, zSpeed, 0.0);
				}
			}
		}
		super.onRemove(state, world, pos, newState, isMoving);
	}

	@Override
	public void onPlace(BlockState state, Level world, BlockPos pos, BlockState oldState, boolean isMoving) {
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (!world.isClientSide) {
			BlockPos originalPos = findOriginalPosition(pos);
			if (originalPos != null && stateMap.containsKey(originalPos)) {
				if (blockEntity instanceof TintableBlockEntity tintableBlockEntity) {
					// Cargar los datos guardados del BlockEntity
					CompoundTag savedData = stateMap.remove(originalPos);
					if (savedData != null) {
						tintableBlockEntity.load(savedData);
						tintableBlockEntity.setChanged(); // Marcar como cambiado
						tintableBlockEntity.sync();
						world.setBlock(pos, state, 3);
					}
					world.sendBlockUpdated(pos, state, state, 3);
				}
			}
			// Genera partículas de polvo al colocar el bloque
			if (blockEntity instanceof TintableBlockEntity tintableBlockEntity) {
				if (tintableBlockEntity.isWaxed()) {
					generateWaxParticles(world, pos, world.random);
				}
				int color = tintableBlockEntity.getColor();
				if (color != -1 && color != 0xFFFFFF && world instanceof ServerLevel serverLevel && isMoving) {
					float[] colorComponents = new float[]{(color >> 16 & 255) / 255.0F, (color >> 8 & 255) / 255.0F, (color & 255) / 255.0F};
					int numParticles = 40; // Número de partículas
					double particleRadius = 0.5; // Radio de generación alrededor del bloque
					float particleSize = 1.5f; // Ajustable según lo que necesites
					for (int i = 0; i < numParticles; i++) {
						double angle = world.random.nextDouble() * 2 * Math.PI;
						double xOffset = Math.cos(angle) * particleRadius;
						double zOffset = Math.sin(angle) * particleRadius;
						double yOffset = (world.random.nextDouble() - 0.5) * 1.6; // Rango ajustado de -0.8 a 0.8
						double xSpeed = (world.random.nextDouble() - 0.5) * 0.1;
						double ySpeed = (world.random.nextDouble() - 0.5) * 0.1;
						double zSpeed = (world.random.nextDouble() - 0.5) * 0.1;
						serverLevel.sendParticles(new DustParticleOptions(new Vector3f(colorComponents[0], colorComponents[1], colorComponents[2]), particleSize), pos.getX() + 0.5 + xOffset, pos.getY() + 0.5 + yOffset, pos.getZ() + 0.5 + zOffset, 1,
								xSpeed, ySpeed, zSpeed, 0.0);
					}
				}
			}
		}
		super.onPlace(state, world, pos, oldState, isMoving);
	}

	private BlockPos findOriginalPosition(BlockPos newPos) {
		for (Map.Entry<BlockPos, CompoundTag> entry : stateMap.entrySet()) {
			BlockPos originalPos = entry.getKey();
			if (originalPos.distSqr(newPos) <= 1) {
				return originalPos;
			}
		}
		return null;
	}

	@Override
	public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
		BlockEntity blockEntity = level.getBlockEntity(pos);
		if (blockEntity instanceof TintableBlockEntity tintableBlockEntity) {
			int color = tintableBlockEntity.getColor();
			level.sendBlockUpdated(pos, state, state, 3);
		}
		if (level.isClientSide) {
			// Obtener los jugadores cercanos (en un rango de 5 bloques alrededor)
			List<Player> players = level.getEntitiesOfClass(Player.class, new AABB(pos).inflate(5));
			for (Player player : players) {
				// Verificar si el jugador tiene un honeycomb en la mano principal o secundaria y está agachado
				ItemStack mainHandItem = player.getMainHandItem();
				ItemStack offHandItem = player.getOffhandItem();
				if (player.isCrouching() && (mainHandItem.getItem() == Items.HONEYCOMB || offHandItem.getItem() == Items.HONEYCOMB)) {
					if (blockEntity instanceof TintableBlockEntity tintableBlockEntity) {
						long currentTime = level.getGameTime(); // Obtener el tiempo actual del juego
						// Comprobar si han pasado al menos 60 ticks desde la última vez que se generaron partículas
						if (currentTime - tintableBlockEntity.getLastWaxParticleTime() >= 45 && tintableBlockEntity.isWaxed()) {
							// Generar partículas de cera
							generateClientWaxParticles(level, pos, random);
							// Actualizar el tiempo de la última generación de partículas
							tintableBlockEntity.setLastWaxParticleTime(currentTime);
						}
					}
					break; // Salimos del bucle si encontramos al menos un jugador con honeycomb agachado
				}
			}
		}
	}

	private void generateClientWaxParticles(Level world, BlockPos pos, RandomSource random) {
		if (world.isClientSide) { // Verificar que esté en el lado del cliente
			int numParticles = 15; // Número de partículas
			double spread = 0.65; // Extensión de partículas hacia los bordes del bloque
			double offsetFromCenter = 0.65; // Para garantizar que las partículas se generen en la superficie
			double centerX = pos.getX() + 0.5;
			double centerY = pos.getY() + 0.5;
			double centerZ = pos.getZ() + 0.5;
			for (int i = 0; i < numParticles; i++) {
				int axis = random.nextInt(3);
				double xOffset = axis == 0 ? (random.nextBoolean() ? offsetFromCenter : -offsetFromCenter) : (random.nextDouble() - 0.5) * spread;
				double yOffset = axis == 1 ? (random.nextBoolean() ? offsetFromCenter : -offsetFromCenter) : (random.nextDouble() - 0.5) * spread;
				double zOffset = axis == 2 ? (random.nextBoolean() ? offsetFromCenter : -offsetFromCenter) : (random.nextDouble() - 0.5) * spread;
				double xSpeed = (random.nextDouble() - 0.5) * 0.05;
				double ySpeed = (random.nextDouble() - 0.5) * 0.05;
				double zSpeed = (random.nextDouble() - 0.5) * 0.05;
				// Usar el método de partículas directamente en el mundo
				world.addParticle(ParticleTypes.WAX_ON, centerX + xOffset, centerY + yOffset, centerZ + zOffset, xSpeed, ySpeed, zSpeed);
			}
		}
	}

	@Override
	public void setPlacedBy(Level world, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
		super.setPlacedBy(world, pos, state, placer, stack);
		BlockEntity blockEntity = world.getBlockEntity(pos);
		if (blockEntity instanceof TintableBlockEntity tintableBlockEntity) {
			if (tintableBlockEntity.isWaxed()) {
				generateWaxParticles(world, pos, world.random);
			}
			if (stack.getItem() instanceof IDyeableItem dyeableItem && dyeableItem.hasColor(stack)) {
				int color = dyeableItem.getColor(stack);
				tintableBlockEntity.setColor(color);
			}
			if (stack.hasTag()) {
				CompoundTag tag = stack.getTag();
				if (tag.contains("Waxed")) {
					boolean waxed = tag.getBoolean("Waxed");
					tintableBlockEntity.setWaxed(waxed);
				}
				if (tag.contains("BlockState")) {
					int blockStateValue = tag.getInt("BlockState");
					world.setBlock(pos, state.setValue(TintableBlock.BLOCKSTATE, blockStateValue), 3);
				}
			}
			tintableBlockEntity.setChanged();
			world.sendBlockUpdated(pos, state, state, 3);
		}
	}

	@OnlyIn(Dist.CLIENT)
	public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
		event.getBlockColors().register((state, world, pos, index) -> {
			if (world != null && pos != null) {
				BlockEntity blockEntity = world.getBlockEntity(pos);
				if (blockEntity instanceof TintableBlockEntity tintableBlockEntity) {
					return tintableBlockEntity.getColor();
				}
			}
			return -1;
		}, JaamsShineriteModBlocks.TINTABLE.get());
	}

	@OnlyIn(Dist.CLIENT)
	public static void itemColorLoad(RegisterColorHandlersEvent.Item event) {
		event.getItemColors().register((stack, index) -> {
			if (stack.getItem() instanceof IDyeableItem dyeableItem) {
				return dyeableItem.getColor(stack);
			}
			return -1;
		}, JaamsShineriteModBlocks.TINTABLE.get().asItem());
	}
}
