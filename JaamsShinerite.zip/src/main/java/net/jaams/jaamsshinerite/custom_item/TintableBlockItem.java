
package net.jaams.jaamsshinerite.custom_item;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;

import net.jaams.jaamsshinerite.dyeable.IDyeableItem;

import javax.annotation.Nullable;

import java.util.List;

public class TintableBlockItem extends BlockItem implements IDyeableItem {
	public TintableBlockItem(Block block, Item.Properties properties) {
		super(block, properties);
	}

	@Override
	public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
		super.appendHoverText(stack, level, tooltip, flag);
		if (flag.isAdvanced() && this.hasColor(stack)) {
			int color = this.getColor(stack);
			String hexColor = String.format("#%06X", (0xFFFFFF & color));
			tooltip.add(Component.literal("Color: ").append(Component.literal(hexColor).withStyle(style -> style.withColor(color))));
		}
		if (!flag.isAdvanced() && this.hasColor(stack)) {
			int color = this.getColor(stack);
			if (color != -1 && color != 0xFFFFFF) {
				tooltip.add(Component.translatable("translation.tooltip.dyed").withStyle(style -> style.withItalic(true).withColor(ChatFormatting.GRAY)));
			}
		}
		if (stack.getOrCreateTag().getBoolean("Waxed")) {
			tooltip.add(Component.translatable("translation.tooltip.waxed").withStyle(style -> style.withItalic(true).withColor(ChatFormatting.GOLD)));
		}
		if (stack.getOrCreateTag().contains("BlockState") && stack.getOrCreateTag().getInt("BlockState") == 1) {
			tooltip.add(Component.translatable("translation.tooltip.inked").withStyle(style -> style.withItalic(true).withColor(ChatFormatting.DARK_GRAY)));
		}
	}

	@Override
	public int getDefaultColor() {
		return -1;
	}

	public boolean isWaxed(ItemStack stack) {
		return stack.getOrCreateTag().getBoolean("Waxed");
	}

	public void setWaxed(ItemStack stack, boolean waxed) {
		stack.getOrCreateTag().putBoolean("Waxed", waxed);
	}
}
