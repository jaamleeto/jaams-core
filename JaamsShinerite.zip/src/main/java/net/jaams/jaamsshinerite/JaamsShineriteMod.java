package net.jaams.jaamsshinerite;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import net.minecraftforge.network.simple.SimpleChannel;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.fml.util.thread.SidedThreadGroups;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.DyeColor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.FriendlyByteBuf;

import net.jaams.jaamsshinerite.registries.ShineriteItems;
import net.jaams.jaamsshinerite.registries.CustomRecipes;
import net.jaams.jaamsshinerite.init.JaamsShineriteModTabs;
import net.jaams.jaamsshinerite.init.JaamsShineriteModSounds;
import net.jaams.jaamsshinerite.init.JaamsShineriteModParticleTypes;
import net.jaams.jaamsshinerite.init.JaamsShineriteModItems;
import net.jaams.jaamsshinerite.init.JaamsShineriteModEntities;
import net.jaams.jaamsshinerite.init.JaamsShineriteModEnchantments;
import net.jaams.jaamsshinerite.init.JaamsShineriteModBlocks;
import net.jaams.jaamsshinerite.init.JaamsShineriteModBlockEntities;
import net.jaams.jaamsshinerite.handler.InteractionHandler;
import net.jaams.jaamsshinerite.dispenser.TintableBlockDispenser;
import net.jaams.jaamsshinerite.dispenser.ShineriteStarDispenser;

import java.util.function.Supplier;
import java.util.function.Function;
import java.util.function.BiConsumer;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.List;
import java.util.Collection;
import java.util.ArrayList;
import java.util.AbstractMap;

@Mod("jaams_shinerite")
public class JaamsShineriteMod {
	public static final Logger LOGGER = LogManager.getLogger(JaamsShineriteMod.class);
	public static final String MODID = "jaams_shinerite";

	public JaamsShineriteMod() {
		// Start of user code block mod constructor
		/*
		// End of user code block mod constructor
		MinecraftForge.EVENT_BUS.register(this);
		IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
		JaamsShineriteModSounds.REGISTRY.register(bus);
		JaamsShineriteModBlocks.REGISTRY.register(bus);
		JaamsShineriteModBlockEntities.REGISTRY.register(bus);
		JaamsShineriteModItems.REGISTRY.register(bus);
		JaamsShineriteModEntities.REGISTRY.register(bus);
		JaamsShineriteModEnchantments.REGISTRY.register(bus);
		JaamsShineriteModTabs.REGISTRY.register(bus);
		JaamsShineriteModParticleTypes.REGISTRY.register(bus);
		// Start of user code block mod init
		*/
		MinecraftForge.EVENT_BUS.register(this);
		IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
		// Default Registry
		JaamsShineriteModSounds.REGISTRY.register(bus);
		JaamsShineriteModBlockEntities.REGISTRY.register(bus);
		JaamsShineriteModBlocks.REGISTRY.register(bus);
		JaamsShineriteModEntities.REGISTRY.register(bus);
		JaamsShineriteModEnchantments.REGISTRY.register(bus);
		JaamsShineriteModTabs.REGISTRY.register(bus);
		JaamsShineriteModParticleTypes.REGISTRY.register(bus);
		// Custom Item Registry
		ShineriteItems.REGISTRY.register(bus);
		// Recipe Registry
		CustomRecipes.REGISTRY.register(bus);
		// Common Setup
		bus.addListener(this::commonSetup);
		// End of user code block mod init
	}

	// Start of user code block mod methods
	private void commonSetup(final FMLCommonSetupEvent event) {
		InteractionHandler.registerCauldronInteractions();
		DispenserBlock.registerBehavior(JaamsShineriteModItems.SHINERITE_STAR.get(), new ShineriteStarDispenser());
		for (DyeColor dyeColor : DyeColor.values()) {
			Item dyeItem = DyeItem.byColor(dyeColor);
			DispenserBlock.registerBehavior(dyeItem, new TintableBlockDispenser());
		}
		DispenserBlock.registerBehavior(Items.HONEYCOMB, new TintableBlockDispenser());
		DispenserBlock.registerBehavior(JaamsShineriteModItems.SHINY_SCRAPER.get(), new TintableBlockDispenser());
		DispenserBlock.registerBehavior(JaamsShineriteModItems.SHINY_PAINT_BRUSH.get(), new TintableBlockDispenser());
		DispenserBlock.registerBehavior(Items.INK_SAC, new TintableBlockDispenser());
		DispenserBlock.registerBehavior(Items.GLOW_INK_SAC, new TintableBlockDispenser());
	}

	// End of user code block mod methods
	private static final String PROTOCOL_VERSION = "1";
	public static final SimpleChannel PACKET_HANDLER = NetworkRegistry.newSimpleChannel(new ResourceLocation(MODID, MODID), () -> PROTOCOL_VERSION, PROTOCOL_VERSION::equals, PROTOCOL_VERSION::equals);
	private static int messageID = 0;

	public static <T> void addNetworkMessage(Class<T> messageType, BiConsumer<T, FriendlyByteBuf> encoder, Function<FriendlyByteBuf, T> decoder, BiConsumer<T, Supplier<NetworkEvent.Context>> messageConsumer) {
		PACKET_HANDLER.registerMessage(messageID, messageType, encoder, decoder, messageConsumer);
		messageID++;
	}

	private static final Collection<AbstractMap.SimpleEntry<Runnable, Integer>> workQueue = new ConcurrentLinkedQueue<>();

	public static void queueServerWork(int tick, Runnable action) {
		if (Thread.currentThread().getThreadGroup() == SidedThreadGroups.SERVER)
			workQueue.add(new AbstractMap.SimpleEntry<>(action, tick));
	}

	@SubscribeEvent
	public void tick(TickEvent.ServerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			List<AbstractMap.SimpleEntry<Runnable, Integer>> actions = new ArrayList<>();
			workQueue.forEach(work -> {
				work.setValue(work.getValue() - 1);
				if (work.getValue() == 0)
					actions.add(work);
			});
			actions.forEach(e -> e.getKey().run());
			workQueue.removeAll(actions);
		}
	}
}
