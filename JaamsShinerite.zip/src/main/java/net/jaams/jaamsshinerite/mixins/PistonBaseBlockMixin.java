package net.jaams.jaamsshinerite.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.piston.PistonBaseBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.Level;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.jaams.jaamsshinerite.block.entity.TintableBlockEntity;

@Mixin(PistonBaseBlock.class)
public abstract class PistonBaseBlockMixin {
	// Capturar cuando los pistones intentan empujar un bloque
	@Inject(method = "isPushable", at = @At("HEAD"), cancellable = true)
	private static void isPushable(BlockState state, Level level, BlockPos pos, Direction direction, boolean destroy, Direction pistonDirection, CallbackInfoReturnable<Boolean> cir) {
		BlockEntity blockEntity = level.getBlockEntity(pos);
		if (blockEntity != null) {
			// Aquí decides si tu bloque personalizado es empujable
			if (blockEntity instanceof TintableBlockEntity) {
				cir.setReturnValue(true);
			}
		}
	}
}
