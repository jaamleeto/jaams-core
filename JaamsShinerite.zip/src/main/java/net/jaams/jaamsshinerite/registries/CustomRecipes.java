
package net.jaams.jaamsshinerite.registries;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.crafting.SimpleCraftingRecipeSerializer;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.core.registries.Registries;

import net.jaams.jaamsshinerite.dyeable.DyeItemRecipe;
import net.jaams.jaamsshinerite.custom_recipes.WaxItemRecipe;
import net.jaams.jaamsshinerite.JaamsShineriteMod;

public class CustomRecipes {
	public static final DeferredRegister<RecipeSerializer<?>> REGISTRY = DeferredRegister.create(Registries.RECIPE_SERIALIZER, JaamsShineriteMod.MODID);
	// Registro de DyeItemRecipe
	public static final RegistryObject<SimpleCraftingRecipeSerializer<DyeItemRecipe>> DYEABLE_ITEM = REGISTRY.register("j_dyeable_item", () -> new SimpleCraftingRecipeSerializer<>(DyeItemRecipe::new));
	// Registro de WaxItemRecipe
	public static final RegistryObject<SimpleCraftingRecipeSerializer<WaxItemRecipe>> WAX_ITEM = REGISTRY.register("j_wax_item", () -> new SimpleCraftingRecipeSerializer<>(WaxItemRecipe::new));
}
