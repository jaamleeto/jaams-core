
package net.jaams.jaamsshinerite.registries;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.jaams.jaamsshinerite.item.ShinyScraperItem;
import net.jaams.jaamsshinerite.item.ShinyRootsItem;
import net.jaams.jaamsshinerite.item.ShinyPaintBrushItem;
import net.jaams.jaamsshinerite.item.ShineriteSwordItem;
import net.jaams.jaamsshinerite.item.ShineriteStarItem;
import net.jaams.jaamsshinerite.item.ShineriteShovelItem;
import net.jaams.jaamsshinerite.item.ShineritePickaxeItem;
import net.jaams.jaamsshinerite.item.ShineriteNuggetItem;
import net.jaams.jaamsshinerite.item.ShineriteIngotItem;
import net.jaams.jaamsshinerite.item.ShineriteHoeItem;
import net.jaams.jaamsshinerite.item.ShineriteAxeItem;
import net.jaams.jaamsshinerite.item.ShinemerangItem;
import net.jaams.jaamsshinerite.item.RawShineriteItem;
import net.jaams.jaamsshinerite.item.GlowSaladItem;
import net.jaams.jaamsshinerite.init.JaamsShineriteModBlocks;
import net.jaams.jaamsshinerite.custom_item.TintableBlockItem;
import net.jaams.jaamsshinerite.JaamsShineriteMod;

public class ShineriteItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, JaamsShineriteMod.MODID);
	public static final RegistryObject<Item> SHINERITE_INGOT = REGISTRY.register("shinerite_ingot", () -> new ShineriteIngotItem());
	public static final RegistryObject<Item> RAW_SHINERITE = REGISTRY.register("raw_shinerite", () -> new RawShineriteItem());
	public static final RegistryObject<Item> SHINERITE_NUGGET = REGISTRY.register("shinerite_nugget", () -> new ShineriteNuggetItem());
	public static final RegistryObject<Item> GLOW_SALAD = REGISTRY.register("glow_salad", () -> new GlowSaladItem());
	public static final RegistryObject<Item> SHINERITE_SWORD = REGISTRY.register("shinerite_sword", () -> new ShineriteSwordItem());
	public static final RegistryObject<Item> SHINERITE_AXE = REGISTRY.register("shinerite_axe", () -> new ShineriteAxeItem());
	public static final RegistryObject<Item> SHINERITE_PICKAXE = REGISTRY.register("shinerite_pickaxe", () -> new ShineritePickaxeItem());
	public static final RegistryObject<Item> SHINERITE_HOE = REGISTRY.register("shinerite_hoe", () -> new ShineriteHoeItem());
	public static final RegistryObject<Item> SHINERITE_SHOVEL = REGISTRY.register("shinerite_shovel", () -> new ShineriteShovelItem());
	public static final RegistryObject<Item> SHINERITE_STAR = REGISTRY.register("shinerite_star", () -> new ShineriteStarItem());
	public static final RegistryObject<Item> SHINEMERANG = REGISTRY.register("shinemerang", () -> new ShinemerangItem());
	public static final RegistryObject<Item> SHINY_ROOTS = REGISTRY.register("shiny_roots", () -> new ShinyRootsItem());
	public static final RegistryObject<Item> TINTABLE = REGISTRY.register("tintable", () -> new TintableBlockItem(JaamsShineriteModBlocks.TINTABLE.get(), new Item.Properties()));
	public static final RegistryObject<Item> SHINY_PAINT_BRUSH = REGISTRY.register("shiny_paint_brush", () -> new ShinyPaintBrushItem());
	public static final RegistryObject<Item> SHINY_SCRAPER = REGISTRY.register("shiny_scraper", () -> new ShinyScraperItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
