
package net.jaams.jaamsshinerite.custom_recipes;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.tags.ItemTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.RegistryAccess;

import net.jaams.jaamsshinerite.registries.CustomRecipes;
import net.jaams.jaamsshinerite.dyeable.IDyeableItem;

public class WaxItemRecipe extends CustomRecipe {
	public WaxItemRecipe(ResourceLocation id, CraftingBookCategory category) {
		super(id, category);
	}

	@Override
	public boolean matches(CraftingContainer container, Level level) {
		ItemStack item = ItemStack.EMPTY;
		boolean hasHoneycomb = false;
		for (int i = 0; i < container.getContainerSize(); i++) {
			ItemStack itemInContainer = container.getItem(i);
			if (!itemInContainer.isEmpty()) {
				if (itemInContainer.getItem() instanceof IDyeableItem && itemInContainer.is(ItemTags.create(new ResourceLocation("jaams_shinerite", "shinerite_weapons")))) {
					if (itemInContainer.getOrCreateTag().getBoolean("Waxed"))
						return false;
					if (!item.isEmpty())
						return false;
					item = itemInContainer;
				} else if (itemInContainer.getItem() instanceof BlockItem && itemInContainer.getItem() instanceof IDyeableItem) {
					if (itemInContainer.getOrCreateTag().getBoolean("Waxed"))
						return false;
					if (!item.isEmpty())
						return false;
					item = itemInContainer;
				} else if (itemInContainer.getItem() == Items.HONEYCOMB) {
					hasHoneycomb = true;
				} else {
					return false;
				}
			}
		}
		return !item.isEmpty() && hasHoneycomb;
	}

	@Override
	public ItemStack assemble(CraftingContainer container, RegistryAccess access) {
		ItemStack item = ItemStack.EMPTY;
		boolean hasHoneycomb = false;
		for (int i = 0; i < container.getContainerSize(); i++) {
			ItemStack itemInContainer = container.getItem(i);
			if (!itemInContainer.isEmpty()) {
				if (itemInContainer.getItem() instanceof IDyeableItem && itemInContainer.is(ItemTags.create(new ResourceLocation("jaams_shinerite", "shinerite_weapons")))) {
					if (!item.isEmpty())
						return ItemStack.EMPTY;
					item = itemInContainer.copy();
				} else if (itemInContainer.getItem() instanceof BlockItem && itemInContainer.getItem() instanceof IDyeableItem) {
					if (!item.isEmpty())
						return ItemStack.EMPTY;
					item = itemInContainer.copy();
				} else if (itemInContainer.getItem() == Items.HONEYCOMB) {
					hasHoneycomb = true;
				}
			}
		}
		if (!item.isEmpty() && hasHoneycomb) {
			item.getOrCreateTag().putBoolean("Waxed", true);
			return item;
		}
		return ItemStack.EMPTY;
	}

	@Override
	public boolean canCraftInDimensions(int width, int height) {
		return width * height >= 2;
	}

	@Override
	public RecipeSerializer<?> getSerializer() {
		return CustomRecipes.WAX_ITEM.get();
	}
}
