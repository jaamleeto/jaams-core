package net.jaams.jaamsshinerite.configuration;

import net.minecraftforge.common.ForgeConfigSpec;

public class JaamsShineriteCommonConfiguration {
	// Builder and Spec (for common configuration)
	public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
	public static final ForgeConfigSpec SPEC;
	// Weapon mechanics
	public static final ForgeConfigSpec.ConfigValue<Boolean> DEFLECT;
	// Projectile behavior
	public static final ForgeConfigSpec.ConfigValue<Boolean> DROPASITEM;
	public static final ForgeConfigSpec.ConfigValue<Boolean> DROPASITEMLAVA;
	// Projectile despawn times
	public static final ForgeConfigSpec.ConfigValue<Double> SHINEMERANGDESPAWN;
	public static final ForgeConfigSpec.ConfigValue<Double> SHINERITESTARDESPAWN;
	// Ranged item behavior
	public static final ForgeConfigSpec.ConfigValue<Boolean> THROWSHINEMERANG;
	public static final ForgeConfigSpec.ConfigValue<Boolean> THROWSHINERITESTAR;
	static {
		// Weapon Mechanics
		BUILDER.push("Weapon Mechanics");
		DEFLECT = BUILDER.comment("Enables or disables the deflect ability.").define("Deflect", true);
		BUILDER.pop();
		// Projectile Behavior
		BUILDER.push("Projectile Behavior");
		DROPASITEM = BUILDER.comment("Enables or disables projectiles dropping as items.").define("Projectile Drop As Item", false);
		DROPASITEMLAVA = BUILDER.comment("Enables or disables projectiles dropping as items in lava.").define("Projectile Drop As Item In Lava", true);
		// Projectile Despawn Time Sub Category
		BUILDER.push("Projectile Despawn Time");
		SHINEMERANGDESPAWN = BUILDER.comment("Despawn time for the shinemerang. Must be between 100 and 72000.").defineInRange("Shinemerang", 1200.0, 100.0, 72000.0);
		SHINERITESTARDESPAWN = BUILDER.comment("Despawn time for the shinerite star. Must be between 100 and 72000.").defineInRange("Shinerite Star", 800.0, 100.0, 72000.0);
		BUILDER.pop();
		BUILDER.pop();
		// Ranged Items Behavior
		BUILDER.push("Ranged Items Behavior");
		THROWSHINEMERANG = BUILDER.comment("Enables or disables throwable shinemerangs.").define("Throwable Shinemerang", true);
		THROWSHINERITESTAR = BUILDER.comment("Enables or disables throwable shinerite stars.").define("Throwable Shinerite Star", true);
		BUILDER.pop();
		// Build the configuration
		SPEC = BUILDER.build();
	}
}
