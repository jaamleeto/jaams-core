package net.jaams.jaamsshinerite.configuration;

import net.minecraftforge.common.ForgeConfigSpec;

public class JaamsShineriteClientConfiguration {
	// Builder and Spec (for client configuration)
	public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
	public static final ForgeConfigSpec SPEC;
	// Projectile size options
	public static final ForgeConfigSpec.ConfigValue<Double> SHINEMERANGSIZE;
	public static final ForgeConfigSpec.ConfigValue<Double> SHINERITESTARSIZE;
	// Camera effects
	public static final ForgeConfigSpec.ConfigValue<Boolean> FOVMODIFIER;
	// FOV modifiers
	public static final ForgeConfigSpec.ConfigValue<Boolean> SHINEMERANGFOV;
	public static final ForgeConfigSpec.ConfigValue<Boolean> SHINERITESTARFOV;
	static {
		// Configuration for projectile sizes
		BUILDER.push("Projectiles Size");
		SHINEMERANGSIZE = BUILDER.comment("Size of the shinemerang. Must be between 1 and 10.").defineInRange("Shinemerang", 1.0, 1.0, 10.0);
		SHINERITESTARSIZE = BUILDER.comment("Size of the shinerite stars. Must be between 1 and 10.").defineInRange("Shinerite Star", 1.5, 1.0, 10.0);
		BUILDER.pop();
		// Configuration for camera effects
		BUILDER.push("Camera Effects");
		FOVMODIFIER = BUILDER.comment("Enables or disables FOV modifier.").define("Fov Modifier", true);
		BUILDER.pop();
		// Configuration for FOV modifiers
		BUILDER.push("FOV Modifier Handler");
		SHINEMERANGFOV = BUILDER.comment("Enables or disables FOV change for the shinemerang.").define("Shinemerang", true);
		SHINERITESTARFOV = BUILDER.comment("Enables or disables FOV change for the shinerite stars.").define("Shinerite Star", true);
		BUILDER.pop();
		// Build the configuration
		SPEC = BUILDER.build();
	}
}
