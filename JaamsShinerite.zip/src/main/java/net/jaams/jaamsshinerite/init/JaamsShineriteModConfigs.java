package net.jaams.jaamsshinerite.init;

import net.minecraftforge.fml.event.lifecycle.FMLConstructModEvent;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import net.jaams.jaamsshinerite.configuration.JaamsShineriteCommonConfiguration;
import net.jaams.jaamsshinerite.configuration.JaamsShineriteClientConfiguration;
import net.jaams.jaamsshinerite.JaamsShineriteMod;

@Mod.EventBusSubscriber(modid = JaamsShineriteMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class JaamsShineriteModConfigs {
	@SubscribeEvent
	public static void register(FMLConstructModEvent event) {
		event.enqueueWork(() -> {
			ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, JaamsShineriteClientConfiguration.SPEC, "jaams_shinerite_client.toml");
			ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, JaamsShineriteCommonConfiguration.SPEC, "jaams_shinerite_common.toml");
		});
	}
}
