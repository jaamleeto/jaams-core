
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.jaams.jaamsshinerite.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.jaams.jaamsshinerite.client.particle.LightstealParticleParticle;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class JaamsShineriteModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(JaamsShineriteModParticleTypes.LIGHTSTEAL_PARTICLE.get(), LightstealParticleParticle::provider);
	}
}
