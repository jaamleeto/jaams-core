
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.jaams.jaamsshinerite.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.jaams.jaamsshinerite.client.renderer.ShineriteStarProjectileRenderer;
import net.jaams.jaamsshinerite.client.renderer.ShinemerangProjectileRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class JaamsShineriteModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(JaamsShineriteModEntities.SHINEMERANG_PROJECTILE.get(), ShinemerangProjectileRenderer::new);
		event.registerEntityRenderer(JaamsShineriteModEntities.SHINERITE_STAR_PROJECTILE.get(), ShineriteStarProjectileRenderer::new);
	}
}
