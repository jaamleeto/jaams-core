
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.jaams.jaamsshinerite.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.jaams.jaamsshinerite.enchantment.LightstealEnchantment;
import net.jaams.jaamsshinerite.enchantment.BrilliancyEnchantment;
import net.jaams.jaamsshinerite.JaamsShineriteMod;

public class JaamsShineriteModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, JaamsShineriteMod.MODID);
	public static final RegistryObject<Enchantment> BRILLIANCY = REGISTRY.register("brilliancy", () -> new BrilliancyEnchantment());
	public static final RegistryObject<Enchantment> LIGHTSTEAL = REGISTRY.register("lightsteal", () -> new LightstealEnchantment());
}
