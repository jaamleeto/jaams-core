
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.jaams.jaamsshinerite.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.jaams.jaamsshinerite.JaamsShineriteMod;

public class JaamsShineriteModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, JaamsShineriteMod.MODID);
	public static final RegistryObject<CreativeModeTab> SHINERITE_TAB = REGISTRY.register("shinerite_tab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.jaams_shinerite.shinerite_tab")).icon(() -> new ItemStack(JaamsShineriteModItems.SHINERITE_INGOT.get())).displayItems((parameters, tabData) -> {
				tabData.accept(JaamsShineriteModItems.SHINERITE_SWORD.get());
				tabData.accept(JaamsShineriteModItems.SHINERITE_AXE.get());
				tabData.accept(JaamsShineriteModItems.SHINERITE_PICKAXE.get());
				tabData.accept(JaamsShineriteModItems.SHINERITE_HOE.get());
				tabData.accept(JaamsShineriteModItems.SHINERITE_SHOVEL.get());
				tabData.accept(JaamsShineriteModItems.SHINERITE_STAR.get());
				tabData.accept(JaamsShineriteModItems.SHINEMERANG.get());
				tabData.accept(JaamsShineriteModItems.SHINY_PAINT_BRUSH.get());
				tabData.accept(JaamsShineriteModItems.SHINY_SCRAPER.get());
				tabData.accept(JaamsShineriteModItems.GLOW_SALAD.get());
				tabData.accept(JaamsShineriteModItems.SHINY_ROOTS.get());
				tabData.accept(JaamsShineriteModItems.SHINERITE_INGOT.get());
				tabData.accept(JaamsShineriteModItems.RAW_SHINERITE.get());
				tabData.accept(JaamsShineriteModItems.SHINERITE_NUGGET.get());
			})

					.build());
}
