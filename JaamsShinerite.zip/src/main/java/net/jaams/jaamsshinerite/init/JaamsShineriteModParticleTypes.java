
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.jaams.jaamsshinerite.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

import net.jaams.jaamsshinerite.JaamsShineriteMod;

public class JaamsShineriteModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, JaamsShineriteMod.MODID);
	public static final RegistryObject<SimpleParticleType> LIGHTSTEAL_PARTICLE = REGISTRY.register("lightsteal_particle", () -> new SimpleParticleType(false));
}
