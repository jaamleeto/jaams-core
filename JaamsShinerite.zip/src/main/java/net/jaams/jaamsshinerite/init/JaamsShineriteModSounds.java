
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.jaams.jaamsshinerite.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.jaams.jaamsshinerite.JaamsShineriteMod;

public class JaamsShineriteModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, JaamsShineriteMod.MODID);
	public static final RegistryObject<SoundEvent> BRILLIANCY_HIT = REGISTRY.register("brilliancy_hit", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("jaams_shinerite", "brilliancy_hit")));
	public static final RegistryObject<SoundEvent> LIGHTSTEAL_HIT = REGISTRY.register("lightsteal_hit", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("jaams_shinerite", "lightsteal_hit")));
	public static final RegistryObject<SoundEvent> EATS_GLOW_ROOTS = REGISTRY.register("eats_glow_roots", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("jaams_shinerite", "eats_glow_roots")));
	public static final RegistryObject<SoundEvent> EATS_GLOW_SALAD = REGISTRY.register("eats_glow_salad", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("jaams_shinerite", "eats_glow_salad")));
	public static final RegistryObject<SoundEvent> SHINERITE_TOOL_HIT = REGISTRY.register("shinerite_tool_hit", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("jaams_shinerite", "shinerite_tool_hit")));
	public static final RegistryObject<SoundEvent> SHINEMERANG_SHOOT = REGISTRY.register("shinemerang_shoot", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("jaams_shinerite", "shinemerang_shoot")));
	public static final RegistryObject<SoundEvent> SHINEMERANG_SHOOT_RESONATES = REGISTRY.register("shinemerang_shoot_resonates", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("jaams_shinerite", "shinemerang_shoot_resonates")));
	public static final RegistryObject<SoundEvent> SHINEMERANG_HIT = REGISTRY.register("shinemerang_hit", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("jaams_shinerite", "shinemerang_hit")));
	public static final RegistryObject<SoundEvent> SHINEMERANG_GROUND = REGISTRY.register("shinemerang_ground", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("jaams_shinerite", "shinemerang_ground")));
	public static final RegistryObject<SoundEvent> SHINERITE_STAR_SHOOT = REGISTRY.register("shinerite_star_shoot", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("jaams_shinerite", "shinerite_star_shoot")));
	public static final RegistryObject<SoundEvent> SHINERITE_STAR_SHOOT_RESONATES = REGISTRY.register("shinerite_star_shoot_resonates",
			() -> SoundEvent.createVariableRangeEvent(new ResourceLocation("jaams_shinerite", "shinerite_star_shoot_resonates")));
	public static final RegistryObject<SoundEvent> SHINERITE_STAR_HIT = REGISTRY.register("shinerite_star_hit", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("jaams_shinerite", "shinerite_star_hit")));
	public static final RegistryObject<SoundEvent> SHINERITE_STAR_GROUND = REGISTRY.register("shinerite_star_ground", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("jaams_shinerite", "shinerite_star_ground")));
	public static final RegistryObject<SoundEvent> EMPTY_SOUND = REGISTRY.register("empty_sound", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("jaams_shinerite", "empty_sound")));
}
