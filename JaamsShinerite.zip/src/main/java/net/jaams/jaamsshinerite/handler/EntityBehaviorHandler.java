
package net.jaams.jaamsshinerite.handler;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.InteractionHand;
import net.minecraft.sounds.SoundSource;

import net.jaams.jaamsshinerite.init.JaamsShineriteModSounds;
import net.jaams.jaamsshinerite.init.JaamsShineriteModItems;
import net.jaams.jaamsshinerite.init.JaamsShineriteModEntities;
import net.jaams.jaamsshinerite.entity.ShineriteStarProjectileEntity;
import net.jaams.jaamsshinerite.entity.ShinemerangProjectileEntity;

import java.util.UUID;
import java.util.Map;
import java.util.HashMap;

@Mod.EventBusSubscriber
public class EntityBehaviorHandler {
	private static final Map<UUID, Boolean> recentAttackMap = new HashMap<>();

	@SubscribeEvent
	public static void onRecentLivingAttack(LivingAttackEvent event) {
		if (event.getSource().getEntity() instanceof LivingEntity attacker) {
			UUID attackerId = attacker.getUUID();
			recentAttackMap.put(attackerId, true);
		}
	}

	private static final Map<LivingEntity, Long> lastShinemerangThrowTime = new HashMap<>();
	private static final double SHINEMERANG_THROW_PROBABILITY = 0.7;
	private static final long SHINEMERANG_THROW_COOLDOWN = 80;
	private static final long SHINEMERANG_PAUSE_AFTER_THROW = 15;
	private static final double MAX_SHINEMERANG_RANGE = 30.0D;

	@SubscribeEvent
	public static void onShinemerangThrow(LivingEvent.LivingTickEvent event) {
		LivingEntity entity = event.getEntity();
		if (!entity.level().isClientSide && entity instanceof Mob mob) {
			ItemStack shinemerangItem = entity.getMainHandItem().is(JaamsShineriteModItems.SHINEMERANG.get())
					? entity.getMainHandItem()
					: entity.getOffhandItem().is(JaamsShineriteModItems.SHINEMERANG.get()) ? entity.getOffhandItem() : ItemStack.EMPTY;
			if (!shinemerangItem.isEmpty() && entity.level().random.nextDouble() < SHINEMERANG_THROW_PROBABILITY && entity.level().getGameTime() - lastShinemerangThrowTime.getOrDefault(entity, 0L) >= SHINEMERANG_THROW_COOLDOWN) {
				LivingEntity target = mob.getTarget();
				if (target != null) {
					double distanceToTarget = target.distanceTo(entity);
					Vec3 directionToTarget = new Vec3(target.getX() - entity.getX(), target.getEyeY() - entity.getEyeY(), target.getZ() - entity.getZ()).normalize();
					Vec3 entityLookDirection = entity.getLookAngle().normalize();
					double angle = directionToTarget.dot(entityLookDirection);
					if (distanceToTarget <= 16.0 && distanceToTarget >= 8.0 && angle > 0.5) {
						InteractionHand hand = shinemerangItem == entity.getMainHandItem() ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND;
						mob.swing(hand, true);
						ShinemerangProjectileEntity projectile = new ShinemerangProjectileEntity(entity.level(), entity, shinemerangItem.copy());
						projectile.setOwner(entity);
						projectile.setPos(entity.getX() + directionToTarget.x, entity.getEyeY() - 0.1, entity.getZ() + directionToTarget.z);
						projectile.shoot(directionToTarget.x, directionToTarget.y, directionToTarget.z, 1.8F, 1.0F);
						double chargeSeconds = SHINEMERANG_THROW_COOLDOWN / 5.0;
						double shinemerangRange = Math.min(5.0D + (chargeSeconds * 2.0D), MAX_SHINEMERANG_RANGE);
						projectile.setBoomerangRange(shinemerangRange);
						projectile.weaponDamage = 4.0F;
						entity.level().addFreshEntity(projectile);
						entity.level().playSound(null, entity.getX(), entity.getY(), entity.getZ(), JaamsShineriteModSounds.SHINEMERANG_SHOOT.get(), SoundSource.HOSTILE, 1.0f, 1.0f);
						shinemerangItem.shrink(1);
						lastShinemerangThrowTime.put(entity, entity.level().getGameTime() + SHINEMERANG_PAUSE_AFTER_THROW);
						mob.getNavigation().stop();
					}
				}
			}
			if (entity.level().getGameTime() > lastShinemerangThrowTime.getOrDefault(entity, 0L)) {
				mob.getNavigation().recomputePath();
			}
		}
	}

	private static final double SHINERITE_STAR_THROW_PROBABILITY = 0.5;
	private static final Map<LivingEntity, Long> lastShineriteStarThrowTime = new HashMap<>();
	private static final long SHINERITE_STAR_THROW_COOLDOWN = 100;
	private static final long SHINERITE_STAR_PAUSE_AFTER_THROW = 20;

	@SubscribeEvent
	public static void onShineriteStarEntityUpdate(LivingEvent.LivingTickEvent event) {
		LivingEntity entity = event.getEntity();
		if (!entity.level().isClientSide && entity instanceof Mob mob) {
			ItemStack shineriteStarItem = entity.getMainHandItem().is(JaamsShineriteModItems.SHINERITE_STAR.get())
					? entity.getMainHandItem()
					: entity.getOffhandItem().is(JaamsShineriteModItems.SHINERITE_STAR.get()) ? entity.getOffhandItem() : ItemStack.EMPTY;
			if (!shineriteStarItem.isEmpty() && entity.level().random.nextDouble() < SHINERITE_STAR_THROW_PROBABILITY && entity.level().getGameTime() - lastShineriteStarThrowTime.getOrDefault(entity, 0L) >= SHINERITE_STAR_THROW_COOLDOWN) {
				LivingEntity target = mob.getTarget();
				if (target != null) {
					double distanceToTarget = target.distanceTo(entity);
					Vec3 directionToTarget = new Vec3(target.getX() - entity.getX(), target.getEyeY() - entity.getEyeY(), target.getZ() - entity.getZ()).normalize();
					Vec3 entityLookDirection = entity.getLookAngle().normalize();
					double angle = directionToTarget.dot(entityLookDirection);
					if (distanceToTarget <= 16.0 && distanceToTarget >= 8.0 && angle > 0.5) {
						InteractionHand hand = shineriteStarItem == entity.getMainHandItem() ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND;
						entity.swing(hand, true);
						ShineriteStarProjectileEntity shineriteStarProjectile = new ShineriteStarProjectileEntity(JaamsShineriteModEntities.SHINERITE_STAR_PROJECTILE.get(), entity, entity.level());
						shineriteStarProjectile.setOwner(entity);
						shineriteStarProjectile.setPos(entity.getX() + directionToTarget.x, entity.getEyeY() - 0.1, entity.getZ() + directionToTarget.z);
						shineriteStarProjectile.shoot(directionToTarget.x, directionToTarget.y, directionToTarget.z, 1.0F, 0.5F);
						entity.level().addFreshEntity(shineriteStarProjectile);
						shineriteStarItem.shrink(1);
						entity.level().playSound(null, entity.getX(), entity.getY(), entity.getZ(), JaamsShineriteModSounds.SHINERITE_STAR_SHOOT.get(), SoundSource.HOSTILE, 1.0F,
								1.0F + (entity.level().random.nextFloat() - entity.level().random.nextFloat()) * 0.2F);
						lastShineriteStarThrowTime.put(entity, entity.level().getGameTime() + SHINERITE_STAR_PAUSE_AFTER_THROW);
						mob.getNavigation().stop();
					}
				}
			}
			if (entity.level().getGameTime() > lastShineriteStarThrowTime.getOrDefault(entity, 0L)) {
				mob.getNavigation().recomputePath();
			}
		}
	}
}
