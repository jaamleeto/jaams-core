
package net.jaams.jaamsshinerite.handler;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.block.LayeredCauldronBlock;
import net.minecraft.world.item.Item;
import net.minecraft.world.InteractionResult;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.core.cauldron.CauldronInteraction;

import net.jaams.jaamsshinerite.init.JaamsShineriteModItems;
import net.jaams.jaamsshinerite.dyeable.IDyeableItem;

import java.util.function.Supplier;
import java.util.List;
import java.util.Arrays;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class InteractionHandler {
	public static void registerCauldronInteractions() {
		CauldronInteraction INTERACTION = (state, level, pos, player, hand, stack) -> {
			Item item = stack.getItem();
			if (!(item instanceof IDyeableItem dyeableItem) || !dyeableItem.hasColor(stack) || stack.getTag() != null && stack.getTag().getBoolean("Waxed")) {
				return InteractionResult.PASS;
			} else {
				if (!level.isClientSide) {
					dyeableItem.removeColor(stack);
					LayeredCauldronBlock.lowerFillLevel(state, level, pos);
					level.playSound(null, pos, SoundEvents.BOTTLE_FILL, SoundSource.BLOCKS, 1.0F, 1.0F);
				}
				return InteractionResult.sidedSuccess(level.isClientSide);
			}
		};
		List<Supplier<Item>> items = Arrays.asList(JaamsShineriteModItems.SHINERITE_SWORD, JaamsShineriteModItems.SHINERITE_AXE, JaamsShineriteModItems.SHINERITE_PICKAXE, JaamsShineriteModItems.SHINERITE_SHOVEL, JaamsShineriteModItems.SHINERITE_HOE,
				JaamsShineriteModItems.SHINEMERANG, JaamsShineriteModItems.SHINERITE_STAR, JaamsShineriteModItems.TINTABLE, JaamsShineriteModItems.SHINY_PAINT_BRUSH, JaamsShineriteModItems.SHINY_SCRAPER);
		for (Supplier<Item> item : items) {
			CauldronInteraction.WATER.put(item.get(), INTERACTION);
		}
	}
}
