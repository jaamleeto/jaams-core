
package net.jaams.jaamsshinerite.handler;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleTypes;

import net.jaams.jaamsshinerite.init.JaamsShineriteModSounds;
import net.jaams.jaamsshinerite.init.JaamsShineriteModParticleTypes;
import net.jaams.jaamsshinerite.init.JaamsShineriteModEnchantments;

@Mod.EventBusSubscriber
public class EnchantmentEventsHandler {
	@SubscribeEvent
	public static void onLivingHurtLightsteal(LivingHurtEvent event) {
		Entity source = event.getSource().getEntity();
		if (!(source instanceof LivingEntity attacker))
			return;
		LivingEntity target = event.getEntity() instanceof LivingEntity ? (LivingEntity) event.getEntity() : null;
		if (target == null)
			return;
		if (target.hasEffect(MobEffects.GLOWING)) {
			ItemStack mainHandItem = attacker.getMainHandItem();
			ItemStack offHandItem = attacker.getOffhandItem();
			if (event.getSource().getDirectEntity() instanceof Player player) {
				ItemStack usedItem = player.getMainHandItem();
				if (!hasLightsteal(usedItem)) {
					return;
				}
				int lightstealLevel = usedItem.getEnchantmentLevel(JaamsShineriteModEnchantments.LIGHTSTEAL.get());
				if (Math.random() < 0.6) {
					attacker.heal(0.5F * lightstealLevel);
					Level world = target.level();
					if (!world.isClientSide()) {
						world.playSound(null, target.getX(), target.getY(), target.getZ(), JaamsShineriteModSounds.LIGHTSTEAL_HIT.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
					}
					if (target.level() instanceof ServerLevel serverLevel) {
						for (int i = 0; i < lightstealLevel; i++) {
							serverLevel.sendParticles(JaamsShineriteModParticleTypes.LIGHTSTEAL_PARTICLE.get(), target.getX() + (Math.random() - 0.5), target.getY() + target.getBbHeight() / 2.0 + (Math.random() - 0.5),
									target.getZ() + (Math.random() - 0.5), 1, 0.0, 0.0, 0.0, 0.0);
						}
					}
				}
			}
		}
	}

	private static boolean hasLightsteal(ItemStack itemStack) {
		return itemStack.getEnchantmentLevel(JaamsShineriteModEnchantments.LIGHTSTEAL.get()) > 0;
	}

	@SubscribeEvent
	public static void onLivingHurtBrilliancy(LivingHurtEvent event) {
		Entity source = event.getSource().getEntity();
		if (!(source instanceof Player attacker))
			return;
		LivingEntity target = event.getEntity();
		if (target.hasEffect(MobEffects.GLOWING)) {
			ItemStack mainHandItem = attacker.getMainHandItem();
			if (hasBrilliancy(mainHandItem)) {
				int brilliancyLevel = mainHandItem.getEnchantmentLevel(JaamsShineriteModEnchantments.BRILLIANCY.get());
				float extraDamage = 1.0F * brilliancyLevel;
				event.setAmount(event.getAmount() + extraDamage);
				Level world = attacker.level();
				if (!world.isClientSide()) {
					world.playSound(null, target.getX(), target.getY(), target.getZ(), JaamsShineriteModSounds.BRILLIANCY_HIT.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
				}
				if (world instanceof ServerLevel serverLevel) {
					for (int i = 0; i < brilliancyLevel; i++) {
						serverLevel.sendParticles(ParticleTypes.FIREWORK, target.getX() + (Math.random() - 0.5), target.getY() + 1.0 + (Math.random() - 0.5), target.getZ() + (Math.random() - 0.5), 1, 0.0, 0.0, 0.0, 0.0); // Una partícula por iteración
					}
				}
			}
		}
	}

	private static boolean hasBrilliancy(ItemStack itemStack) {
		return itemStack.getEnchantmentLevel(JaamsShineriteModEnchantments.BRILLIANCY.get()) > 0;
	}
}
