
package net.jaams.jaamsshinerite.handler;

import org.checkerframework.checker.units.qual.g;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;

import net.jaams.jaamsshinerite.dyeable.IDyeableItem;

@Mod.EventBusSubscriber
public class JaamNametagHandler {
	@SubscribeEvent
	public static void onPlayerJaamColorTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			Player player = event.player;
			Level level = player.level();
			if (!level.isClientSide) {
				for (int slot = 0; slot < player.getInventory().getContainerSize(); slot++) {
					ItemStack stack = player.getInventory().getItem(slot);
					processItemName(stack, level);
				}
			}
		}
	}

	private static void processItemName(ItemStack stack, Level level) {
		if (stack.hasCustomHoverName() && stack.getItem() instanceof IDyeableItem dyeableItem) {
			String itemName = stack.getHoverName().getString();
			int currentColor = dyeableItem.getColor(stack);
			int targetColor = -1;
			if ("jaam".equalsIgnoreCase(itemName)) {
				targetColor = 0xFF0000;
			} else if ("leeto".equalsIgnoreCase(itemName)) {
				targetColor = 0x000000;
			}
			if (targetColor != -1 && currentColor != targetColor) {
				int tickCounter = stack.getOrCreateTag().getInt("TickCounter");
				tickCounter++;
				if (tickCounter >= 5) {
					int smoothColor = interpolateColor(currentColor, targetColor, 0.1f);
					dyeableItem.setColor(stack, smoothColor);
					tickCounter = 0;
				}
				stack.getOrCreateTag().putInt("TickCounter", tickCounter);
			}
		}
	}

	private static int interpolateColor(int color1, int color2, float factor) {
		int r1 = (color1 >> 16) & 0xFF;
		int g1 = (color1 >> 8) & 0xFF;
		int b1 = color1 & 0xFF;
		int r2 = (color2 >> 16) & 0xFF;
		int g2 = (color2 >> 8) & 0xFF;
		int b2 = color2 & 0xFF;
		int r = (int) (r1 + (r2 - r1) * factor);
		int g = (int) (g1 + (g2 - g1) * factor);
		int b = (int) (b1 + (b2 - b1) * factor);
		return (r << 16) | (g << 8) | b;
	}
}
