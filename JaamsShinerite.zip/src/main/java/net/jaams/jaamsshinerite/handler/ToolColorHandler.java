
package net.jaams.jaamsshinerite.handler;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.tags.ItemTags;
import net.minecraft.resources.ResourceLocation;

import net.jaams.jaamsshinerite.dyeable.IDyeableItem;

import java.util.UUID;
import java.util.Map;
import java.util.HashMap;

@Mod.EventBusSubscriber
public class ToolColorHandler {
	private static final Map<UUID, Integer> rainTickCounterMap = new HashMap<>();

	@SubscribeEvent
	public static void onPlayerColorTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			Player player = event.player;
			Level level = player.level();
			if (!level.isClientSide) {
				int rainTickCounter = rainTickCounterMap.getOrDefault(player.getUUID(), 0);
				rainTickCounter = processItemInHand(player.getMainHandItem(), level, player, rainTickCounter);
				rainTickCounter = processItemInHand(player.getOffhandItem(), level, player, rainTickCounter);
				rainTickCounterMap.put(player.getUUID(), rainTickCounter);
			}
		}
	}

	private static int processItemInHand(ItemStack stack, Level level, Player player, int rainTickCounter) {
		if (stack.hasCustomHoverName()) {
			String itemName = stack.getHoverName().getString();
			if (itemName.equalsIgnoreCase("jaam") || itemName.equalsIgnoreCase("leeto")) {
				return rainTickCounter;
			}
		}
		if (stack.hasTag() && stack.getTag().contains("Waxed")) {
			return rainTickCounter;
		}
		if ((stack.is(ItemTags.create(new ResourceLocation("jaams_shinerite", "shinerite_weapons"))) || stack.is(ItemTags.create(new ResourceLocation("jaams_shinerite", "shinerite_tools")))) && stack.getItem() instanceof IDyeableItem dyeableItem) {
			boolean isRaining = level.isRainingAt(player.blockPosition().above()) && level.canSeeSky(player.blockPosition().above());
			if (isRaining || player.isUnderWater()) {
				rainTickCounter++;
				if (rainTickCounter >= 50) {
					int currentColor = ((IDyeableItem) stack.getItem()).getColor(stack);
					if (currentColor != 0xFFFFFF) {
						int lightenedColor = lightenColor(currentColor, 0.05f);
						((IDyeableItem) stack.getItem()).setColor(stack, lightenedColor);
					}
					rainTickCounter = 0;
				}
			} else {
				rainTickCounter = 0;
			}
		}
		return rainTickCounter;
	}

	private static int lightenColor(int color, float amount) {
		int red = (color >> 16) & 0xFF;
		int green = (color >> 8) & 0xFF;
		int blue = color & 0xFF;
		red = Math.min(255, (int) (red + (255 - red) * amount));
		green = Math.min(255, (int) (green + (255 - green) * amount));
		blue = Math.min(255, (int) (blue + (255 - blue) * amount));
		return (red << 16) | (green << 8) | blue;
	}
}
