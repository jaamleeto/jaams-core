
package net.jaams.jaamsshinerite.dyeable;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.jaams.jaamsshinerite.registries.ShineriteItems;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ColorRegister {
	@OnlyIn(Dist.CLIENT)
	@SubscribeEvent
	public static void onItemColorRegister(RegisterColorHandlersEvent.Item event) {
		event.register((stack, tintIndex) -> tintIndex > 0 ? -1 : ((IDyeableItem) stack.getItem()).getColor(stack), ShineriteItems.SHINERITE_SWORD.get(), ShineriteItems.SHINERITE_AXE.get(), ShineriteItems.SHINERITE_PICKAXE.get(),
				ShineriteItems.SHINERITE_SHOVEL.get(), ShineriteItems.SHINERITE_HOE.get(), ShineriteItems.SHINEMERANG.get(), ShineriteItems.SHINERITE_STAR.get(), ShineriteItems.SHINY_PAINT_BRUSH.get(), ShineriteItems.SHINY_SCRAPER.get());
	}
}
