package net.jaams.jaamsshinerite.dispenser;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.core.dispenser.AbstractProjectileDispenseBehavior;
import net.minecraft.core.Position;

import net.jaams.jaamsshinerite.init.JaamsShineriteModEntities;
import net.jaams.jaamsshinerite.entity.ShineriteStarProjectileEntity;

public class ShineriteStarDispenser extends AbstractProjectileDispenseBehavior {
	@Override
	protected Projectile getProjectile(Level level, Position pos, ItemStack stack) {
		ShineriteStarProjectileEntity entity = new ShineriteStarProjectileEntity(JaamsShineriteModEntities.SHINERITE_STAR_PROJECTILE.get(), level);
		entity.weaponItem = stack.copy();
		entity.setPos(pos.x(), pos.y(), pos.z());
		entity.pickup = AbstractArrow.Pickup.ALLOWED;
		return entity;
	}
}
