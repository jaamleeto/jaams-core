package net.jaams.jaamsshinerite.dispenser;

import org.joml.Vector3f;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.DyeColor;
import net.minecraft.util.RandomSource;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.dispenser.DefaultDispenseItemBehavior;
import net.minecraft.core.BlockSource;
import net.minecraft.core.BlockPos;

import net.jaams.jaamsshinerite.item.ShinyScraperItem;
import net.jaams.jaamsshinerite.item.ShinyPaintBrushItem;
import net.jaams.jaamsshinerite.block.entity.TintableBlockEntity;
import net.jaams.jaamsshinerite.block.TintableBlock;

public class TintableBlockDispenser extends DefaultDispenseItemBehavior {
	@Override
	protected ItemStack execute(BlockSource source, ItemStack stack) {
		Level world = source.getLevel();
		BlockPos pos = source.getPos().relative(source.getBlockState().getValue(DispenserBlock.FACING));
		BlockState state = world.getBlockState(pos);
		if (world.getBlockEntity(pos) instanceof TintableBlockEntity blockEntity) {
			Item item = stack.getItem();
			if (blockEntity.isWaxed() && (item instanceof ShinyPaintBrushItem || item instanceof DyeItem || item == Items.INK_SAC || item == Items.GLOW_INK_SAC)) {
				generateWaxParticles(world, pos, world.random);
				return stack;
			}
			if (blockEntity.isWaxed()) {
				if (item instanceof ShinyScraperItem) {
					blockEntity.setWaxed(false);
					world.playSound(null, pos, SoundEvents.AXE_WAX_OFF, SoundSource.BLOCKS, 1.0F, 1.0F);
					generateWaxRemovalParticles(world, pos);
					return reduceItemStack(source, stack);
				}
				return stack;
			}
			int blockColor = blockEntity.getColor();
			if (item instanceof ShinyPaintBrushItem dyeableItem) {
				if (dyeableItem.hasColor(stack)) {
					int color = dyeableItem.getColor(stack);
					if (color == blockColor || (color == DyeColor.BLACK.getTextColor() && blockColor == lightenColor(DyeColor.BLACK.getTextColor()))) {
						return stack;
					}
					if (color == DyeColor.BLACK.getTextColor()) {
						color = lightenColor(color);
					}
					applyDye(world, pos, state, color);
					reduceItemStack(source, stack);
					blockEntity.setChanged();
					world.sendBlockUpdated(pos, state, state, 3);
					return stack;
				}
			} else if (item instanceof DyeItem dyeItem) {
				int color = dyeItem.getDyeColor().getTextColor();
				if (color == blockColor || (dyeItem.getDyeColor() == DyeColor.BLACK && blockColor == lightenColor(DyeColor.BLACK.getTextColor()))) {
					return stack;
				}
				if (dyeItem.getDyeColor() == DyeColor.BLACK) {
					color = lightenColor(color);
				}
				applyDye(world, pos, state, color);
				stack.shrink(1);
				blockEntity.setChanged();
				world.sendBlockUpdated(pos, state, state, 3);
				return stack;
			}
			if (item instanceof ShinyScraperItem && blockColor != -1 && blockColor != 0xFFFFFF) {
				applyDye(world, pos, state, -1);
				return reduceItemStack(source, stack);
			}
			if (item == Items.HONEYCOMB) {
				blockEntity.setWaxed(true);
				stack.shrink(1);
				blockEntity.setChanged();
				generateWaxParticles(world, pos, world.random);
				world.sendBlockUpdated(pos, state, state, 3);
				world.playSound(null, pos, SoundEvents.HONEYCOMB_WAX_ON, SoundSource.BLOCKS, 1.0F, 1.0F);
				return stack;
			}
		}
		if (state.getBlock() instanceof TintableBlock) {
			if (stack.getItem() == Items.INK_SAC && state.getValue(TintableBlock.BLOCKSTATE) != 1) {
				world.setBlock(pos, state.setValue(TintableBlock.BLOCKSTATE, 1), 3);
				generateInkParticles(world, pos, new Vector3f(0.0f, 0.0f, 0.0f));
				world.playSound(null, pos, SoundEvents.INK_SAC_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
				stack.shrink(1);
				return stack;
			} else if (stack.getItem() == Items.GLOW_INK_SAC && state.getValue(TintableBlock.BLOCKSTATE) != 0) {
				world.setBlock(pos, state.setValue(TintableBlock.BLOCKSTATE, 0), 3);
				generateInkParticles(world, pos, new Vector3f(0.0f, 1.0f, 1.0f));
				world.playSound(null, pos, SoundEvents.GLOW_INK_SAC_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
				stack.shrink(1);
				return stack;
			}
		}
		return super.execute(source, stack);
	}

	private void generateInkParticles(Level world, BlockPos pos, Vector3f color) {
		if (world instanceof ServerLevel serverLevel) {
			RandomSource random = serverLevel.random;
			int particleCount = 20;
			float particleSize = 1.5f;
			double speed = 0.1;
			double radius = 0.5;
			for (int i = 0; i < particleCount; i++) {
				double angle = random.nextDouble() * 2 * Math.PI;
				double xOffset = Math.cos(angle) * radius;
				double zOffset = Math.sin(angle) * radius;
				double yOffset = (random.nextDouble() - 0.5) * 1.6;
				double xSpeed = (random.nextDouble() - 0.5) * speed;
				double ySpeed = (random.nextDouble() - 0.5) * speed;
				double zSpeed = (random.nextDouble() - 0.5) * speed;
				serverLevel.sendParticles(new DustParticleOptions(color, particleSize), pos.getX() + 0.5 + xOffset, // Generación alrededor del centro del bloque en X
						pos.getY() + 0.5 + yOffset, pos.getZ() + 0.5 + zOffset, 1, xSpeed, ySpeed, zSpeed, 0.0);
			}
		}
	}

	private ItemStack reduceItemStack(BlockSource source, ItemStack itemstack) {
		if (itemstack.isDamageableItem() && itemstack.getMaxStackSize() == 1) {
			if (itemstack.hurt(1, source.getLevel().random, null)) {
				itemstack.setCount(0);
			}
		} else {
			itemstack.shrink(1);
		}
		return itemstack;
	}

	private void generateWaxParticles(Level world, BlockPos pos, RandomSource random) {
		if (!world.isClientSide) {
			int numParticles = 20;
			double spread = 0.65;
			double offsetFromCenter = 0.7;
			double centerX = pos.getX() + 0.5;
			double centerY = pos.getY() + 0.5;
			double centerZ = pos.getZ() + 0.5;
			for (int i = 0; i < numParticles; i++) {
				int axis = random.nextInt(3);
				double xOffset = axis == 0 ? (random.nextBoolean() ? offsetFromCenter : -offsetFromCenter) : (random.nextDouble() - 0.5) * spread;
				double yOffset = axis == 1 ? (random.nextBoolean() ? offsetFromCenter : -offsetFromCenter) : (random.nextDouble() - 0.5) * spread;
				double zOffset = axis == 2 ? (random.nextBoolean() ? offsetFromCenter : -offsetFromCenter) : (random.nextDouble() - 0.5) * spread;
				double xSpeed = (random.nextDouble() - 0.5) * 0.02;
				double ySpeed = (random.nextDouble() - 0.5) * 0.02;
				double zSpeed = (random.nextDouble() - 0.5) * 0.02;
				((ServerLevel) world).sendParticles(ParticleTypes.WAX_ON, centerX + xOffset, centerY + yOffset, centerZ + zOffset, 1, xSpeed, ySpeed, zSpeed, 0.25);
			}
		}
	}

	private void generateWaxRemovalParticles(Level world, BlockPos pos) {
		RandomSource random = world.random;
		if (!world.isClientSide) {
			int numParticles = 20;
			double spread = 0.65;
			double offsetFromCenter = 0.7;
			double centerX = pos.getX() + 0.5;
			double centerY = pos.getY() + 0.5;
			double centerZ = pos.getZ() + 0.5;
			for (int i = 0; i < numParticles; i++) {
				int axis = random.nextInt(3);
				double xOffset = axis == 0 ? (random.nextBoolean() ? offsetFromCenter : -offsetFromCenter) : (random.nextDouble() - 0.5) * spread;
				double yOffset = axis == 1 ? (random.nextBoolean() ? offsetFromCenter : -offsetFromCenter) : (random.nextDouble() - 0.5) * spread;
				double zOffset = axis == 2 ? (random.nextBoolean() ? offsetFromCenter : -offsetFromCenter) : (random.nextDouble() - 0.5) * spread;
				double xSpeed = (random.nextDouble() - 0.5) * 0.02;
				double ySpeed = (random.nextDouble() - 0.5) * 0.02;
				double zSpeed = (random.nextDouble() - 0.5) * 0.02;
				((ServerLevel) world).sendParticles(ParticleTypes.WAX_OFF, centerX + xOffset, centerY + yOffset, centerZ + zOffset, 1, xSpeed, ySpeed, zSpeed, 0.25);
			}
		}
	}

	private int lightenColor(int color) {
		int red = (color >> 16) & 0xFF;
		int green = (color >> 8) & 0xFF;
		int blue = color & 0xFF;
		red = Math.min(255, red + 30);
		green = Math.min(255, green + 30);
		blue = Math.min(255, blue + 30);
		return (red << 16) | (green << 8) | blue;
	}

	private void applyDye(Level world, BlockPos pos, BlockState state, int color) {
		if (world.getBlockEntity(pos) instanceof TintableBlockEntity blockEntity) {
			blockEntity.setColor(color);
			world.sendBlockUpdated(pos, state, state, 3);
			world.playSound(null, pos, SoundEvents.DYE_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
			float[] colorComponents = new float[]{(color >> 16 & 255) / 255.0F, (color >> 8 & 255) / 255.0F, (color & 255) / 255.0F};
			int numParticles = 50;
			double particleRadius = 0.5;
			for (int i = 0; i < numParticles; i++) {
				double angle = world.random.nextDouble() * 2 * Math.PI;
				double xOffset = Math.cos(angle) * particleRadius;
				double zOffset = Math.sin(angle) * particleRadius;
				double yOffset = world.random.nextDouble();
				double xSpeed = (world.random.nextDouble() - 0.5) * 0.1;
				double ySpeed = world.random.nextDouble() * 0.1;
				double zSpeed = (world.random.nextDouble() - 0.5) * 0.1;
				world.addParticle(new DustParticleOptions(new Vector3f(colorComponents[0], colorComponents[1], colorComponents[2]), 1.0F), pos.getX() + 0.5 + xOffset, // Generar alrededor del bloque
						pos.getY() + yOffset, pos.getZ() + 0.5 + zOffset, xSpeed, ySpeed, zSpeed);
			}
		}
	}
}
