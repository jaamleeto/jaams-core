
package net.jaams.jaamsshinerite.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class ShineriteNuggetItem extends Item {
	public ShineriteNuggetItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
