
package net.jaams.jaamsshinerite.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class RawShineriteItem extends Item {
	public RawShineriteItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
