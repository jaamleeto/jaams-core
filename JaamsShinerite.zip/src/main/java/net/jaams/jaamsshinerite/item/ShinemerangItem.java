
package net.jaams.jaamsshinerite.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;
import net.minecraft.stats.Stats;
import net.minecraft.sounds.SoundSource;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;

import net.jaams.jaamsshinerite.init.JaamsShineriteModSounds;
import net.jaams.jaamsshinerite.init.JaamsShineriteModItems;
import net.jaams.jaamsshinerite.entity.ShinemerangProjectileEntity;
import net.jaams.jaamsshinerite.dyeable.IDyeableItem;

import javax.annotation.Nullable;

import java.util.List;

public class ShinemerangItem extends SwordItem implements IDyeableItem {
	private static final double MAX_BOOMERANG_RANGE = 20.0D;

	public ShinemerangItem() {
		super(new Tier() {
			public int getUses() {
				return 232;
			}

			public float getSpeed() {
				return 6f;
			}

			public float getAttackDamageBonus() {
				return -1.5f;
			}

			public int getLevel() {
				return 2;
			}

			public int getEnchantmentValue() {
				return 16;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(JaamsShineriteModItems.SHINERITE_INGOT.get()));
			}
		}, 3, -1.8f, new Item.Properties());
	}

	@Override
	public int getDefaultColor() {
		return -1;
	}

	@Override
	public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
		return false;
	}

	@Override
	public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
		super.appendHoverText(stack, level, tooltip, flag);
		// Si el item tiene color
		if (this.hasColor(stack)) {
			int color = this.getColor(stack);
			// Mostrar el color y su código solo si el modo de depuración está activado
			if (flag.isAdvanced()) {
				String hexColor = String.format("#%06X", (0xFFFFFF & color));
				// Agrega "Color: #XXXXXX" en una sola línea
				tooltip.add(Component.literal("Color: ").append(Component.literal(hexColor).withStyle(style -> style.withColor(color))));
			} else {
				// Mostrar "Dyed" si el color no es el predeterminado (-1) y no está en modo avanzado
				if (color != -1 && color != 0xFFFFFF) {
					tooltip.add(Component.translatable("translation.tooltip.dyed").withStyle(style -> style.withItalic(true).withColor(ChatFormatting.GRAY)));
				}
			}
		}
		// Si el item está encerado, mostrar siempre
		if (stack.getOrCreateTag().getBoolean("Waxed")) {
			tooltip.add(Component.translatable("translation.tooltip.waxed").withStyle(style -> style.withItalic(true).withColor(ChatFormatting.GOLD)));
		}
	}

	@Override
	public int getBarColor(ItemStack stack) {
		if (this.hasColor(stack)) {
			return this.getColor(stack);
		}
		return super.getBarColor(stack);
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		if (sourceentity != null) {
			Level world = sourceentity.level();
			world.playSound(null, sourceentity.getX(), sourceentity.getY(), sourceentity.getZ(), JaamsShineriteModSounds.SHINERITE_TOOL_HIT.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
			if (entity.getHealth() <= 0.0F && !world.isClientSide()) {
				// La entidad ha muerto, duplica la experiencia
				if (entity instanceof Mob mob) {
					int experience = mob.getExperienceReward();
					world.addFreshEntity(new ExperienceOrb(world, entity.getX(), entity.getY(), entity.getZ(), experience * 2));
				}
			}
		}
		return retval;
	}

	@Override
	public UseAnim getUseAnimation(ItemStack itemstack) {
		return UseAnim.SPEAR;
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 72000;
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
		ItemStack itemStack = player.getItemInHand(hand);
		if (itemStack.getDamageValue() >= itemStack.getMaxDamage() - 1) {
			return InteractionResultHolder.fail(itemStack);
		}
		player.startUsingItem(hand);
		return InteractionResultHolder.consume(itemStack);
	}

	@Override
	public void releaseUsing(ItemStack weaponStack, Level world, LivingEntity entity, int chargeTicks) {
		if (entity instanceof Player player) {
			int useDuration = this.getUseDuration(weaponStack) - chargeTicks;
			if (useDuration >= 5) {
				if (!world.isClientSide) {
					weaponStack.hurtAndBreak(1, player, (brokenStack) -> {
						brokenStack.broadcastBreakEvent(entity.getUsedItemHand());
					});
					ShinemerangProjectileEntity projectile = new ShinemerangProjectileEntity(world, player, weaponStack.copy());
					projectile.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 1.8F + (float) 0.0F * 0.5F, 1.0F);
					projectile.weaponItem = weaponStack.copy();
					double chargeSeconds = useDuration / 5.0;
					double boomerangRange = 5.0D + (chargeSeconds * 2.0D);
					if (boomerangRange > MAX_BOOMERANG_RANGE) {
						boomerangRange = MAX_BOOMERANG_RANGE;
					}
					projectile.setBoomerangRange(boomerangRange);
					projectile.weaponDamage = 4.0F;
					if (player.getAbilities().instabuild) {
						projectile.pickup = AbstractArrow.Pickup.CREATIVE_ONLY;
					}
					world.addFreshEntity(projectile);
					world.playSound(null, player.getX(), player.getY(), player.getZ(), JaamsShineriteModSounds.SHINEMERANG_SHOOT.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
					world.playSound(null, player.getX(), player.getY(), player.getZ(), JaamsShineriteModSounds.SHINEMERANG_SHOOT_RESONATES.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
					if (!player.getAbilities().instabuild) {
						weaponStack.shrink(1);
					}
					player.awardStat(Stats.ITEM_USED.get(this));
				}
			}
		}
	}
}
