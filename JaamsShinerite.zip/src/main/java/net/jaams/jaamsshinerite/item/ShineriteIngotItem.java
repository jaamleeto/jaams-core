
package net.jaams.jaamsshinerite.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class ShineriteIngotItem extends Item {
	public ShineriteIngotItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
