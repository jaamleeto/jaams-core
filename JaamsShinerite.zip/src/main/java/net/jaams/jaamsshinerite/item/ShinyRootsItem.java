
package net.jaams.jaamsshinerite.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.sounds.SoundSource;

import net.jaams.jaamsshinerite.init.JaamsShineriteModSounds;
import net.jaams.jaamsshinerite.JaamsShineriteMod;

public class ShinyRootsItem extends Item {
	public ShinyRootsItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON).food((new FoodProperties.Builder()).nutrition(1).saturationMod(0.3f).alwaysEat().build()));
	}

	@Override
	public ItemStack finishUsingItem(ItemStack stack, Level world, LivingEntity entity) {
		ItemStack resultStack = super.finishUsingItem(stack, world, entity);
		if (!world.isClientSide && entity instanceof Player) {
			Player player = (Player) entity;
			// 60% chance to apply Glowing effect
			if (world.random.nextFloat() < 0.6f) {
				entity.addEffect(new MobEffectInstance(MobEffects.GLOWING, 60, 0));
				JaamsShineriteMod.queueServerWork(5, () -> {
					if (!entity.level().isClientSide()) {
						world.playSound(null, entity.getX(), entity.getY(), entity.getZ(), JaamsShineriteModSounds.EATS_GLOW_ROOTS.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
					}
				});
			}
			// 30% chance to give random extra experience points between 1 and 6
			if (world.random.nextFloat() < 0.8f) {
				int extraXp = world.random.nextInt(6) + 1; // Generates a random number between 1 and 6
				player.giveExperiencePoints(extraXp);
			}
		}
		return resultStack;
	}
}
