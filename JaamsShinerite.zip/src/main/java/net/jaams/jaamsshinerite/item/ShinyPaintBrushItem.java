
package net.jaams.jaamsshinerite.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;

import net.jaams.jaamsshinerite.dyeable.IDyeableItem;

import javax.annotation.Nullable;

import java.util.List;

public class ShinyPaintBrushItem extends Item implements IDyeableItem {
	public ShinyPaintBrushItem() {
		super(new Item.Properties().durability(160).rarity(Rarity.COMMON));
	}

	@Override
	public int getDefaultColor() {
		return -1;
	}

	@Override
	public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
		return false;
	}

	@Override
	public boolean hasCraftingRemainingItem() {
		return true;
	}

	@Override
	public ItemStack getCraftingRemainingItem(ItemStack itemstack) {
		ItemStack retval = new ItemStack(this);
		retval.setDamageValue(itemstack.getDamageValue() + 1);
		if (retval.getDamageValue() >= retval.getMaxDamage()) {
			return ItemStack.EMPTY;
		}
		return retval;
	}

	@Override
	public boolean isRepairable(ItemStack itemstack) {
		return false;
	}

	@Override
	public int getBarColor(ItemStack stack) {
		if (this.hasColor(stack)) {
			return this.getColor(stack);
		}
		return super.getBarColor(stack);
	}

	@Override
	public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
		super.appendHoverText(stack, level, tooltip, flag);
		// Si el item tiene color
		if (this.hasColor(stack)) {
			int color = this.getColor(stack);
			// Mostrar el color y su código solo si el modo de depuración está activado
			if (flag.isAdvanced()) {
				String hexColor = String.format("#%06X", (0xFFFFFF & color));
				// Agrega "Color: #XXXXXX" en una sola línea
				tooltip.add(Component.literal("Color: ").append(Component.literal(hexColor).withStyle(style -> style.withColor(color))));
			} else {
				// Mostrar "Dyed" si el color no es el predeterminado (-1) y no está en modo avanzado
				if (color != -1 && color != 0xFFFFFF) {
					tooltip.add(Component.translatable("translation.tooltip.dyed").withStyle(style -> style.withItalic(true).withColor(ChatFormatting.GRAY)));
				}
			}
		}
	}
}
