
package net.jaams.jaamsshinerite.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.Advancement;

import net.jaams.jaamsshinerite.init.JaamsShineriteModSounds;
import net.jaams.jaamsshinerite.JaamsShineriteMod;

public class GlowSaladItem extends Item {
	public GlowSaladItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON).food((new FoodProperties.Builder()).nutrition(3).saturationMod(0.3f).alwaysEat().build()));
	}

	@Override
	public ItemStack finishUsingItem(ItemStack itemstack, Level world, LivingEntity entity) {
		ItemStack retval = new ItemStack(Items.BOWL);
		super.finishUsingItem(itemstack, world, entity);
		if (!world.isClientSide && entity instanceof Player) {
			Player player = (Player) entity;
			// Apply effects
			entity.addEffect(new MobEffectInstance(MobEffects.GLOWING, 300, 0));
			entity.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 300, 0));
			// Play sound after a delay
			JaamsShineriteMod.queueServerWork(5, () -> {
				if (!entity.level().isClientSide())
					world.playSound(null, entity.getX(), entity.getY(), entity.getZ(), JaamsShineriteModSounds.EATS_GLOW_SALAD.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
			});
			// Grant random experience between 1 and 16
			int extraXp = world.random.nextInt(16) + 1; // Generates a random number between 1 and 16
			player.giveExperiencePoints(extraXp);
		}
		// Grant advancement
		if (entity instanceof ServerPlayer _player) {
			Advancement _adv = _player.server.getAdvancements().getAdvancement(new ResourceLocation("jaams_shinerite:glowing_lunch_advancement"));
			AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
			if (!_ap.isDone()) {
				for (String criteria : _ap.getRemainingCriteria())
					_player.getAdvancements().award(_adv, criteria);
			}
		}
		// Handle itemstack and return bowl
		if (itemstack.isEmpty()) {
			return retval;
		} else {
			if (entity instanceof Player player && !player.getAbilities().instabuild) {
				if (!player.getInventory().add(retval))
					player.drop(retval, false);
			}
			return itemstack;
		}
	}
}
