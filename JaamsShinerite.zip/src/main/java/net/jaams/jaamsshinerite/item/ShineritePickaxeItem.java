
package net.jaams.jaamsshinerite.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.sounds.SoundSource;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;

import net.jaams.jaamsshinerite.init.JaamsShineriteModSounds;
import net.jaams.jaamsshinerite.init.JaamsShineriteModItems;
import net.jaams.jaamsshinerite.dyeable.IDyeableItem;

import javax.annotation.Nullable;

import java.util.List;

public class ShineritePickaxeItem extends PickaxeItem implements IDyeableItem {
	public ShineritePickaxeItem() {
		super(new Tier() {
			public int getUses() {
				return 632;
			}

			public float getSpeed() {
				return 6f;
			}

			public float getAttackDamageBonus() {
				return 1f;
			}

			public int getLevel() {
				return 2;
			}

			public int getEnchantmentValue() {
				return 16;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(JaamsShineriteModItems.SHINERITE_INGOT.get()));
			}
		}, 1, -2.6f, new Item.Properties());
	}

	@Override
	public int getDefaultColor() {
		return -1;
	}

	@Override
	public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
		return false;
	}

	@Override
	public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
		super.appendHoverText(stack, level, tooltip, flag);
		// Si el item tiene color
		if (this.hasColor(stack)) {
			int color = this.getColor(stack);
			// Mostrar el color y su código solo si el modo de depuración está activado
			if (flag.isAdvanced()) {
				String hexColor = String.format("#%06X", (0xFFFFFF & color));
				// Agrega "Color: #XXXXXX" en una sola línea
				tooltip.add(Component.literal("Color: ").append(Component.literal(hexColor).withStyle(style -> style.withColor(color))));
			} else {
				// Mostrar "Dyed" si el color no es el predeterminado (-1) y no está en modo avanzado
				if (color != -1 && color != 0xFFFFFF) {
					tooltip.add(Component.translatable("translation.tooltip.dyed").withStyle(style -> style.withItalic(true).withColor(ChatFormatting.GRAY)));
				}
			}
		}
		// Si el item está encerado, mostrar siempre
		if (stack.getOrCreateTag().getBoolean("Waxed")) {
			tooltip.add(Component.translatable("translation.tooltip.waxed").withStyle(style -> style.withItalic(true).withColor(ChatFormatting.GOLD)));
		}
	}

	@Override
	public int getBarColor(ItemStack stack) {
		if (this.hasColor(stack)) {
			return this.getColor(stack);
		}
		return super.getBarColor(stack);
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		if (sourceentity != null) {
			Level world = sourceentity.level();
			world.playSound(null, sourceentity.getX(), sourceentity.getY(), sourceentity.getZ(), JaamsShineriteModSounds.SHINERITE_TOOL_HIT.get(), SoundSource.PLAYERS, 1.0f, 1.0f);
			if (entity.getHealth() <= 0.0F && !world.isClientSide()) {
				// La entidad ha muerto, duplica la experiencia
				if (entity instanceof Mob mob) {
					int experience = mob.getExperienceReward();
					world.addFreshEntity(new ExperienceOrb(world, entity.getX(), entity.getY(), entity.getZ(), experience * 2));
				}
			}
		}
		return retval;
	}
}
